import csv, json, re, math, zipfile, shutil, os
from pathlib import Path
from datetime import datetime, timedelta
from investment_engine import confirm_opportunities, position_state, roi_pace, recommended_candidate_budget

VERSION='3.60.33'
BASELINE=9913.04
NEW_CONTRIBUTION=5055.52
CONTRIBUTION_DATE='2026-07-10'
PRE_CONTRIBUTION_VALUE=13017.99
TOTAL_CONTRIBUTIONS=BASELINE+NEW_CONTRIBUTION
ROOT=Path(__file__).resolve().parent

# Fidelity cash and money-market positions are portfolio liquidity, not
# tradable equity candidates. They must contribute to effective cash while
# remaining excluded from OPS scoring and buy/sell ladder generation.
CASH_EQUIVALENT_SYMBOLS = {
    'CASH', 'FCASH', 'FCASH**', 'FDRXX', 'PDRXX', 'SPAXX', 'SPRXX',
}

# BR-086 Practical Share Rounding. LadderIQ rounds executable ladder quantities
# to reduce order-entry keystrokes. Quantities normally use one decimal place;
# values within 0.15 share of a whole number are rounded to that whole share.
# Sell ladders are subsequently capped so rounding can never recommend selling
# more shares than the model-authorized quantity or the position actually owned.
def round_trade_shares(value):
    try:
        value=max(0.0, float(value or 0))
    except (TypeError, ValueError):
        return 0.0
    nearest=round(value)
    if nearest >= 1 and abs(value-nearest) <= 0.15:
        return float(nearest)
    return round(value, 1)

def rounded_split_quantities(total_qty, splits):
    total=max(0.0, float(total_qty or 0))
    out=[]
    used=0.0
    for i, split in enumerate(splits):
        raw=total*float(split)
        q=round_trade_shares(raw)
        remaining=max(0.0, total-used)
        q=min(q, remaining)
        # Keep final displayed precision practical and never exceed the cap.
        q=round(q, 1)
        out.append(q)
        used=round(used+q, 10)
    return out

def is_cash_equivalent(symbol='', description=''):
    sym=str(symbol or '').strip().upper()
    desc=str(description or '').strip().upper()
    return (
        sym in CASH_EQUIVALENT_SYMBOLS
        or 'HELD IN FCASH' in desc
        or 'MONEY MARKET' in desc
        or 'GOVERNMENT CASH RESERVES' in desc
    )

def effective_ladder_datetime(now=None):
    """Return the single Eastern-time date used everywhere in the UI.

    BR-018: At or after 4:00 PM ET, the ladder remains labeled for the
    current Eastern calendar day. Before 4:00 PM ET it also uses the current
    business day; weekend runs roll forward to Monday. The important control
    is that every label consumes this one value instead of recalculating it.
    """
    from zoneinfo import ZoneInfo
    et = (now or datetime.now(ZoneInfo('America/New_York'))).astimezone(ZoneInfo('America/New_York'))
    while et.weekday() >= 5:
        et += timedelta(days=1)
    return et

_LADDER_DT=effective_ladder_datetime()
LADDER_FOR=_LADDER_DT.strftime('%A, %B %d, %Y').replace(' 0',' ')

# Thesis-driven positions intentionally managed outside normal OPS qualification.
# Keep this set centralized so classification, buy/sell rules, and execution
# guidance stay aligned when a new Special Situation is added.
SPECIAL_SITUATION_SYMBOLS = {'SPCX', 'MP'}



# BR-082 Vacation / unattended-order guidance.
# This is execution guidance only; it does not change ladder prices, shares,
# OPS, recommendations, or capital allocation.  L1 buys remain DAY orders;
# deeper L2/L3 buys and ordinary sell ladders are generally GTC candidates.
# Known catalysts, Special Situations, and materially negative recent news are
# flagged REVIEW so an unattended order is not implied to be safe.
VACATION_CATALYST_WINDOWS = {
    # Earnings week exceptions discussed for the Aug-2026 vacation protocol.
    # These expire automatically after the event window.
    'NVDA': ('2026-08-24', '2026-08-27', 'Earnings / major catalyst window'),
    'CRWD': ('2026-08-24', '2026-08-27', 'Earnings / major catalyst window'),
}

def vacation_review_reason(stock):
    sym=str(stock.get('symbol') or '').upper()
    group=str(stock.get('group') or '')
    if group == 'Special Situations':
        return 'Special Situation — review before leaving unattended'
    news_adj=float(stock.get('news_adjustment') or 0)
    if news_adj <= -5.0:
        return f'Material negative news ({news_adj:.1f}) — review first'
    window=VACATION_CATALYST_WINDOWS.get(sym)
    if window:
        start,end,reason=window
        today=_LADDER_DT.strftime('%Y-%m-%d')
        if start <= today <= end:
            return reason
    return ''

def apply_vacation_order_guidance(stock):
    reason=vacation_review_reason(stock)
    for rung in stock.get('buy', []):
        status=str(rung.get('status') or '')
        if not status.startswith('Active'):
            rung['duration']='WAIT'
            rung['duration_reason']='Not yet confirmed / active'
        elif reason:
            rung['duration']='REVIEW'
            rung['duration_reason']=reason
        elif int(rung.get('level') or 0) == 1:
            rung['duration']='DAY'
            rung['duration_reason']='Closest buy rung; refresh daily'
        else:
            rung['duration']='GTC'
            rung['duration_reason']='Deeper pullback rung; suitable for unattended GTC protocol'
    for rung in stock.get('sell', []):
        if reason:
            rung['duration']='REVIEW'
            rung['duration_reason']=reason
        else:
            rung['duration']='GTC'
            rung['duration_reason']='Predetermined harvest level; suitable for unattended GTC protocol'

def positions_file_date(path):
    match = re.search(r'Portfolio_Positions_([A-Za-z]{3})-(\d{1,2})-(\d{4})(?: \(\d+\))?\.csv$', path.name, re.IGNORECASE)
    if not match:
        return None
    try:
        return datetime.strptime('-'.join(match.groups()[:3]), '%b-%d-%Y')
    except ValueError:
        return None

def format_data_as_of(path):
    file_date = positions_file_date(path)
    if file_date is None:
        file_date = datetime.fromtimestamp(path.stat().st_mtime)
    return file_date.strftime('%Y-%m-%d') + ' ET (After Hours)'

def money_to_float(s):
    if s is None: return 0.0
    s=str(s).strip().replace('$','').replace(',','').replace('%','')
    if s in ('','nan','None'): return 0.0
    neg=False
    if s.startswith('(') and s.endswith(')'):
        neg=True; s=s[1:-1]
    if s.startswith('+'): s=s[1:]
    try: v=float(s)
    except: return 0.0
    return -v if neg else v

def fmt_money(x): return f"${float(x):,.2f}"
def fmt_pct(x): return f"{float(x):.2f}%"
def fmt_sh(x):
    x=float(x)
    return f"{x:.3f}".rstrip('0').rstrip('.')

def find_latest_positions_csv():
    files = list(ROOT.glob('Portfolio_Positions*.csv'))
    files = [f for f in files if f.is_file()]
    if not files:
        raise FileNotFoundError('No positions CSV found. Expected Portfolio_Positions*.csv')
    dated = [(positions_file_date(f), f) for f in files]
    dated = [(d, f) for d, f in dated if d is not None]
    if dated:
        return max(dated, key=lambda item: (item[0], item[1].stat().st_mtime))[1]
    return max(files, key=lambda f: f.stat().st_mtime)

def read_positions():
    path=find_latest_positions_csv()
    print(f'Using positions CSV: {path}')
    pos={}; cash=0; pending=0
    target_account='Z25686771'
    excluded_symbols={'QQQ'}
    with open(path, encoding='utf-8-sig', newline='') as f:
        reader=csv.DictReader(f)
        if 'Account number' not in (reader.fieldnames or []):
            raise KeyError("Missing required Fidelity 'Account number' column. LadderIQ will not build a portfolio without an account boundary.")
        target_rows=0
        for row in reader:
            account=(row.get('Account number') or '').strip()
            if account != target_account:
                continue
            target_rows += 1
            sym=(row.get('Symbol') or '').strip().upper()
            description=row.get('Description') or ''
            if sym in excluded_symbols:
                continue
            if is_cash_equivalent(sym, description):
                cash += money_to_float(row.get('Current Value') or row.get('Current value'))
            elif sym=='Pending activity' or 'PENDING ACTIVITY' in sym.upper() or 'PENDING ACTIVITY' in description.upper():
                pending += money_to_float(row.get('Current Value') or row.get('Current value'))
            elif sym and sym not in ('', 'SYMBOL') and row.get('Quantity'):
                pos[sym]={
                    'symbol':sym,
                    'company':row.get('Description') or sym,
                    'quantity':money_to_float(row.get('Quantity')),
                    'price':money_to_float(row.get('Last Price') or row.get('Last price')),
                    'value':money_to_float(row.get('Current Value') or row.get('Current value')),
                    'today_pl':money_to_float(row.get("Today's Gain/Loss Dollar") or row.get("Today's gain/loss dollar")),
                    'today_pl_pct':money_to_float(row.get("Today's Gain/Loss Percent") or row.get("Today's gain/loss percent")),
                    'total_pl':money_to_float(row.get('Total Gain/Loss Dollar') or row.get('Total gain/loss dollar')),
                    'total_pl_pct':money_to_float(row.get('Total Gain/Loss Percent') or row.get('Total gain/loss percent')),
                    'weight':money_to_float(row.get('Percent Of Account') or row.get('Percent of account')),
                    'cost_basis':money_to_float(row.get('Cost Basis Total') or row.get('Cost basis total')),
                    'avg_cost':money_to_float(row.get('Average Cost Basis') or row.get('Average cost basis')),
                }
        if target_rows == 0:
            raise ValueError(f'No Fidelity position rows found for LadderIQ account {target_account}.')
    return pos, cash, pending, path.name

def read_scores():
    path=ROOT/'leadership_scores.json'
    scores={}
    if path.exists():
        data=json.load(open(path))
        for bucket in ['scores','current_leaders','emerging_leaders','weakening_leaders']:
            for item in data.get(bucket,[]) or []:
                symbol=str(item.get('symbol') or '').strip().upper()
                if not symbol or is_cash_equivalent(symbol, item.get('company') or item.get('description') or ''):
                    continue
                scores[symbol]=item
    return scores

positions,cash,pending,pos_file=read_positions()
DATA_AS_OF=format_data_as_of(ROOT / pos_file)
scores=read_scores()
score_payload = json.load(open(ROOT/'leadership_scores.json', encoding='utf-8')) if (ROOT/'leadership_scores.json').exists() else {}
shadow_regime = score_payload.get('shadow_market_regime') or {'score': None, 'regime': 'Pending', 'shadow_capital_pct': 100, 'shadow_only': True, 'affects_live_ladders': False, 'components': {}}
shadow_capital_preservation = score_payload.get('shadow_capital_preservation') or {'score': None, 'regime': 'Pending', 'shadow_capital_pct': 100, 'shadow_only': True, 'affects_live_ladders': False, 'pillars': {}}
confirmation = confirm_opportunities(scores, ROOT, score_payload.get('market_session_date') or score_payload.get('as_of'), threshold=95.0)

# Growth Candidates are discovered automatically by leadership_scanner.py from
# the broad U.S. market. watchlist.json is retained only for backward
# compatibility and has no role in candidate discovery or ranking.
GROWTH_CANDIDATE_MIN_SCORE = 95
GROWTH_CANDIDATE_EMERGING_SCORE = 90

# Position Lifecycle Manager
# One source of truth for whether a symbol belongs on the active dashboard.
# States: owned, active_candidate, watchlist, recently_exited, archived.
LIFECYCLE_PATH = ROOT / 'position_lifecycle.json'
DEFAULT_LIFECYCLE = {
    'version': '1.0',
    'settings': {
        'recent_exit_days': 0,
        'hide_archived_from_dashboard': True
    },
    'symbols': {
        'AMZN': {
            'state': 'archived',
            'reason': 'Position fully liquidated; removed from active dashboard.',
            'manual': True
        },
        'ARM': {
            'state': 'active_candidate',
            'reason': 'Growth candidate based on opportunity score; monitored for approval.',
            'manual': True
        }
    }
}

def load_lifecycle():
    if LIFECYCLE_PATH.exists():
        try:
            data=json.load(open(LIFECYCLE_PATH, encoding='utf-8'))
            if isinstance(data, dict):
                data.setdefault('settings', DEFAULT_LIFECYCLE['settings'].copy())
                data.setdefault('symbols', {})
                return data
        except Exception as exc:
            print(f'WARNING: Could not read position_lifecycle.json: {exc}')
    return json.loads(json.dumps(DEFAULT_LIFECYCLE))

def save_lifecycle(data):
    data['last_updated']=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    LIFECYCLE_PATH.write_text(json.dumps(data, indent=2), encoding='utf-8')

lifecycle=load_lifecycle()

def base_stock(sym, group, rank, role, status, target, subtitle=''):
    s=scores.get(sym,{})
    p=positions.get(sym,{})
    price=p.get('price') or float(s.get('price') or 0)
    qty=p.get('quantity',0.0); value=p.get('value',0.0)
    leadership=float(s.get('leadership_score', {'TSM':100,'PANW':100,'ANET':100,'NVDA':35,'AMZN':35,'ASML':100,'CRWD':90,'AMD':100,'SPCX':72,'ARM':74}.get(sym,0)))
    confirm_meta=confirmation.get(sym, {'confirmed_score': leadership, 'streak': 2, 'qualified_candidate': leadership >= 95, 'qualified_100': leadership >= 100, 'immediate_risk_override': False})
    confirmed_opportunity=float(confirm_meta.get('confirmed_score', leadership))
    # v3.60.21: News refinement is applied AFTER the two-session confirmation
    # layer. This makes the actionable score internally consistent: e.g.,
    # Confirmed OPS 43 + News Impact -8.1 = News-Refined OPS 34.9.
    news_adjustment=float(s.get('news_adjustment',0) or 0)
    actionable_opportunity=round(confirmed_opportunity + news_adjustment, 1)
    # Positive news may rank/strengthen an already-qualified setup, but it may
    # not manufacture buy eligibility. Negative news may remove eligibility.
    eligibility_opportunity=round(confirmed_opportunity + min(news_adjustment, 0.0), 1)
    trend='Up' if leadership>=75 else ('Lateral' if leadership>=30 else 'Down')
    if sym in ['AMZN','META']: trend='Down'
    if sym=='NVDA': trend='Lateral'
    rotation={'TSM':88,'PANW':83,'ANET':74,'NVDA':38,'AMZN':32,'ASML':98,'CRWD':92,'AMD':88,'SPCX':56,'ARM':52}.get(sym, int(max(0, leadership-20)))
    company=s.get('company') or {'TSM':'Taiwan Semiconductor Manufacturing Co.','PANW':'Palo Alto Networks','ANET':'Arista Networks','NVDA':'NVIDIA Corporation','AMZN':'Amazon.com','ASML':'ASML Holding','CRWD':'CrowdStrike Holdings','AMD':'Advanced Micro Devices','SPCX':'Space Exploration Tech','META':'Meta Platforms','ARM':'Arm Holdings','SNOW':'Snowflake','DELL':'Dell Technologies','PLTR':'Palantir Technologies','VRT':'Vertiv Holdings','AVGO':'Broadcom','MSFT':'Microsoft','GOOGL':'Alphabet','ORCL':'Oracle','NOW':'ServiceNow','SMCI':'Super Micro Computer'}.get(sym, p.get('company',sym))
    business_quality=float(s.get('business_quality', {'ASML':100,'TSM':99,'NVDA':98,'PANW':97,'CRWD':96,'ANET':95,'AMD':91,'AMZN':88,'SPCX':72,'ARM':83}.get(sym, max(50, leadership))))
    score_reason={'NVDA':'World-class AI company, but overweight and in harvest mode; new capital priority remains low.', 'AMZN':'Quality business, but currently a rotation/exit candidate.', 'TSM':'Strategic AI infrastructure leader with active accumulation priority.', 'ASML':'Strategic semiconductor monopoly-style asset and approved growth engine.', 'ANET':'AI networking leader with current leadership confirmation.', 'PANW':'Cybersecurity leader and current capital deployment candidate.', 'CRWD':'Cybersecurity growth leader and current capital deployment candidate.', 'AMD':'AI/datacenter challenger; active growth-engine candidate.', 'SPCX':'Special situation; governed by separate risk rules.', 'ARM':'Growth candidate with a qualifying opportunity score; no active ladder until approval.'}.get(sym, 'Opportunity score controls where the next dollar goes today; business quality is tracked separately.')
    own_reason={'SPCX':'Special Situation','ARM':'Growth Candidate'}.get(sym, 'LadderIQ Selected')
    return {**p, 'symbol':sym, 'company':company, 'sector':s.get('sector','Unknown'), 'industry':s.get('industry','Unknown'), 'expected_upside_pct':float(s.get('expected_upside_pct') or 0), 'reward_to_risk':float(s.get('reward_to_risk') or 0), 'return_velocity':float(s.get('return_velocity') or 0), 'sector_leadership_score':float(s.get('sector_leadership_score') or 50), 'composite_score':float(s.get('composite_score') or leadership), 'candidate_eligible':bool(s.get('candidate_eligible', False)), 'group':group, 'rank':rank, 'role':role, 'status':status, 'target':target, 'subtitle':subtitle, 'price':price, 'quantity':qty, 'value':value, 'leadership':leadership, 'opportunity':actionable_opportunity, 'raw_opportunity':leadership, 'confirmed_ops':confirmed_opportunity, 'confirmation_days':int(confirm_meta.get('streak',1)), 'qualified_candidate':bool(confirm_meta.get('qualified_candidate', confirmed_opportunity >= 95 and int(confirm_meta.get('streak',0)) >= 2)) and eligibility_opportunity >= 95, 'qualified_100':bool(confirm_meta.get('qualified_100')) and eligibility_opportunity >= 100, 'immediate_risk_override':bool(confirm_meta.get('immediate_risk_override')), 'score_data':s, 'base_ops':float(s.get('base_ops', leadership) or leadership), 'news_adjustment':news_adjustment, 'final_ops':actionable_opportunity, 'eligibility_ops':eligibility_opportunity, 'news_risk_level':s.get('news_risk_level','Not Checked'), 'news_reason':s.get('news_reason',''), 'news_sources':s.get('news_sources',[]) or [], 'business_quality':business_quality, 'score_reason':score_reason, 'own_reason':own_reason, 'trend':trend, 'rotation':rotation, 'avg_cost':p.get('avg_cost',0), 'weight':p.get('weight',0), 'total_pl':p.get('total_pl',0), 'total_pl_pct':p.get('total_pl_pct',0), 'today_pl':p.get('today_pl',0), 'today_pl_pct':p.get('today_pl_pct',0)}

stocks=[
 base_stock('TSM','Core Compounders',1,'P1 Leader','Accumulate','40–50%','Best-in-class leader'),
 base_stock('PANW','Core Compounders',2,'P1 Leader','Accumulate','40–50%','Cybersecurity core'),
 base_stock('ANET','Tactical Compounders',1,'P2 Tactical','Accumulate','20–40%','High-growth tactical leader'),
 base_stock('NVDA','Tactical Compounders',2,'P2 Harvest','Harvest','20–40%','No fresh buy while opportunity <50'),
 base_stock('AMZN','Tactical Compounders',3,'P3 Harvest','Harvest','20–40%','Two-step exit candidate'),
 base_stock('ASML','Growth Engine',1,'Incubator','Seed','10–20%','Approved incubator'),
 base_stock('CRWD','Growth Engine',2,'Incubator','Seed','10–20%','Approved incubator'),
 base_stock('AMD','Growth Engine',3,'Incubator','Seed','10–20%','Approved incubator'),
 base_stock('SPCX','Special Situations',1,'Special','Hold','5–10%','Strategic special situation'),
]

# Section 5 is generated fresh from every broad-market symbol that passed the
# scanner's eligibility, quality and 100-OPS tier. Personal watchlist membership
# is deliberately ignored.
owned_symbols = {sym for sym, pos in positions.items() if float(pos.get('quantity') or 0) >= 0.0005 and float(pos.get('value') or 0) >= 1.00}
candidate_symbols = []
confirmed_candidate_symbols = []
for sym, row in scores.items():
    raw_score = float(row.get('eligibility_ops') if row.get('eligibility_ops') is not None else (row.get('leadership_score') or 0))
    meta = confirmation.get(sym, {})
    # New broad-market payloads explicitly provide candidate_eligible. Older
    # cached score files predate that field, so use a conservative score-based
    # fallback instead of silently producing an empty candidate section.
    eligible = bool(row.get('candidate_eligible')) if 'candidate_eligible' in row else raw_score >= GROWTH_CANDIDATE_EMERGING_SCORE
    if sym in owned_symbols or not eligible or raw_score < GROWTH_CANDIDATE_EMERGING_SCORE:
        continue
    candidate_symbols.append(sym)
    if bool(meta.get('qualified_candidate')) or (float(meta.get('confirmed_score') or 0) >= GROWTH_CANDIDATE_MIN_SCORE and int(meta.get('streak') or 0) >= 2):
        confirmed_candidate_symbols.append(sym)
candidate_symbols.sort(key=lambda sym: (
    -float((scores.get(sym) or {}).get('final_ops') if (scores.get(sym) or {}).get('final_ops') is not None else ((scores.get(sym) or {}).get('leadership_score') or 0)),
    -float((scores.get(sym) or {}).get('return_velocity') or 0),
    -float((scores.get(sym) or {}).get('reward_to_risk') or 0),
    -float((scores.get(sym) or {}).get('business_quality') or 0),
    sym,
))
for candidate_rank, sym in enumerate(candidate_symbols, start=1):
    meta=confirmation.get(sym,{})
    confirmed=sym in confirmed_candidate_symbols
    status='Candidate' if confirmed else 'Emerging'
    subtitle=('Confirmed broad-market growth candidate' if confirmed else f"Automatic broad-market candidate · confirmation {int(meta.get('streak') or 1)}/2")
    stocks.append(base_stock(sym,'Growth Candidates',candidate_rank,'Growth Candidate',status,'0–10%',subtitle))

# BR-087 Candidate Deduplication. Fixed architecture names (for example AMD)
# can also qualify through the broad-market scanner. A symbol must exist only
# once in the working collection or the later classification engine can render
# the same non-owned ticker twice in Growth Candidates. For non-owned names,
# prefer the fresh scanner candidate record; for owned names, prefer the
# portfolio-management record.
_dedup={}
for _st in stocks:
    _sym=_st.get('symbol')
    if not _sym:
        continue
    _existing=_dedup.get(_sym)
    if _existing is None:
        _dedup[_sym]=_st
        continue
    _owned=_sym in owned_symbols
    if _owned:
        if _existing.get('group') == 'Growth Candidates' and _st.get('group') != 'Growth Candidates':
            _dedup[_sym]=_st
    else:
        if _st.get('group') == 'Growth Candidates':
            _dedup[_sym]=_st
stocks=list(_dedup.values())

# Ensure every brokerage holding is managed even when it was not part of the
# historical fixed portfolio architecture.
existing_symbols = {s['symbol'] for s in stocks}
for sym in sorted(owned_symbols - existing_symbols):
    stocks.append(base_stock(sym,'Tactical Compounders',99,'Owned Position','Manage','Dynamic','Imported holding; automatically included for management'))

# Active holdings drive management ladders; qualified non-owned names can remain visible as growth candidates. META removed in V43.
position_sum=sum(p['value'] for p in positions.values())
account_total=cash+pending+position_sum
effective_cash=cash+pending
deployable=effective_cash*.85
# Performance accounting: contributions are capital events, not investment gains.
# Personal ROI measures wealth growth against all contributed capital.
net_gain=account_total-TOTAL_CONTRIBUTIONS
personal_roi=(net_gain/TOTAL_CONTRIBUTIONS*100) if TOTAL_CONTRIBUTIONS else 0.0
# Time-weighted return breaks the history at the 2026-07-10 contribution.
period1_return=(PRE_CONTRIBUTION_VALUE/BASELINE)-1 if BASELINE else 0.0
period2_return=((account_total-NEW_CONTRIBUTION)/PRE_CONTRIBUTION_VALUE)-1 if PRE_CONTRIBUTION_VALUE else 0.0
twr=((1+period1_return)*(1+period2_return)-1)*100
roi=twr
roi_pacing=roi_pace(roi, '2026-04-07', DATA_AS_OF)
capital_ledger=[
    {'date':'2026-04-07','type':'Initial contribution','amount':BASELINE,'notes':'LadderIQ inception capital'},
    {'date':CONTRIBUTION_DATE,'type':'External contribution','amount':NEW_CONTRIBUTION,'notes':'Booz Allen SPP / vested stock contribution'},
]
# Today's PL from CSV rows
today_pl=sum(v.get('today_pl',0) for v in positions.values())
today_pl_pct=today_pl/account_total*100 if account_total else 0

# QQQ benchmark + replay series for Benchmark card.
# Start date is locked at 2026-04-07; slider end date updates benchmark metrics.
QQQ_BENCHMARK={
  "symbol": "QQQ",
  "start_date": "2026-04-07",
  "end_date": "2026-07-09",
  "start_price": 588.59,
  "end_price": 723.28,
  "return_pct": 22.883501248746985,
  "portfolio_return_pct": 31.32187502521931,
  "alpha_pct": 8.438373776472325,
  "status": "Outperforming",
  "series": [
    {
      "date": "2026-04-07",
      "price": 588.59
    },
    {
      "date": "2026-04-08",
      "price": 606.09
    },
    {
      "date": "2026-04-09",
      "price": 610.19
    },
    {
      "date": "2026-04-10",
      "price": 611.07
    },
    {
      "date": "2026-04-13",
      "price": 617.39
    },
    {
      "date": "2026-04-14",
      "price": 628.6
    },
    {
      "date": "2026-04-15",
      "price": 637.4
    },
    {
      "date": "2026-04-16",
      "price": 640.47
    },
    {
      "date": "2026-04-17",
      "price": 648.85
    },
    {
      "date": "2026-04-20",
      "price": 646.79
    },
    {
      "date": "2026-04-21",
      "price": 644.33
    },
    {
      "date": "2026-04-22",
      "price": 655.11
    },
    {
      "date": "2026-04-23",
      "price": 651.42
    },
    {
      "date": "2026-04-24",
      "price": 663.88
    },
    {
      "date": "2026-04-27",
      "price": 664.23
    },
    {
      "date": "2026-04-28",
      "price": 657.55
    },
    {
      "date": "2026-04-29",
      "price": 661.57
    },
    {
      "date": "2026-04-30",
      "price": 667.74
    },
    {
      "date": "2026-05-01",
      "price": 674.15
    },
    {
      "date": "2026-05-04",
      "price": 672.88
    },
    {
      "date": "2026-05-05",
      "price": 681.61
    },
    {
      "date": "2026-05-06",
      "price": 695.77
    },
    {
      "date": "2026-05-07",
      "price": 694.94
    },
    {
      "date": "2026-05-08",
      "price": 711.23
    },
    {
      "date": "2026-05-11",
      "price": 713.29
    },
    {
      "date": "2026-05-12",
      "price": 707.24
    },
    {
      "date": "2026-05-13",
      "price": 714.71
    },
    {
      "date": "2026-05-14",
      "price": 719.79
    },
    {
      "date": "2026-05-15",
      "price": 708.93
    },
    {
      "date": "2026-05-18",
      "price": 705.88
    },
    {
      "date": "2026-05-19",
      "price": 701.53
    },
    {
      "date": "2026-05-20",
      "price": 713.15
    },
    {
      "date": "2026-05-21",
      "price": 714.51
    },
    {
      "date": "2026-05-22",
      "price": 717.54
    },
    {
      "date": "2026-05-26",
      "price": 730.28
    },
    {
      "date": "2026-05-27",
      "price": 729.45
    },
    {
      "date": "2026-05-28",
      "price": 735.6
    },
    {
      "date": "2026-05-29",
      "price": 738.31
    },
    {
      "date": "2026-06-01",
      "price": 742.74
    },
    {
      "date": "2026-06-02",
      "price": 746.16
    },
    {
      "date": "2026-06-03",
      "price": 744.21
    },
    {
      "date": "2026-06-04",
      "price": 740.61
    },
    {
      "date": "2026-06-05",
      "price": 705.06
    },
    {
      "date": "2026-06-08",
      "price": 716.07
    },
    {
      "date": "2026-06-09",
      "price": 707.83
    },
    {
      "date": "2026-06-10",
      "price": 693.69
    },
    {
      "date": "2026-06-11",
      "price": 717.12
    },
    {
      "date": "2026-06-12",
      "price": 721.34
    },
    {
      "date": "2026-06-15",
      "price": 744.0
    },
    {
      "date": "2026-06-16",
      "price": 729.86
    },
    {
      "date": "2026-06-17",
      "price": 722.51
    },
    {
      "date": "2026-06-18",
      "price": 740.62
    },
    {
      "date": "2026-06-22",
      "price": 737.95
    },
    {
      "date": "2026-06-23",
      "price": 713.65
    },
    {
      "date": "2026-06-24",
      "price": 710.62
    },
    {
      "date": "2026-06-25",
      "price": 716.38
    },
    {
      "date": "2026-06-26",
      "price": 706.52
    },
    {
      "date": "2026-06-29",
      "price": 724.08
    },
    {
      "date": "2026-06-30",
      "price": 736.4
    },
    {
      "date": "2026-07-01",
      "price": 725.17
    },
    {
      "date": "2026-07-02",
      "price": 712.6
    },
    {
      "date": "2026-07-06",
      "price": 722.82
    },
    {
      "date": "2026-07-07",
      "price": 709.43
    },
    {
      "date": "2026-07-08",
      "price": 711.44
    }
  ],
  "buy_hold_return_pct": 1.8215512861112781,
  "ladder_alpha_pct": 29.500323739108033,
  "ladder_value_added": 2924.3788923872744,
  "notes": "V54 restores full replay benchmark card after V53 regression. Slider starts 2026-04-07 and updates portfolio, QQQ, buy-and-hold, and LadderIQ value."
}
QQQ_BENCHMARK['replay_series']=[
  {
    "date": "2026-04-07",
    "portfolio_value": 9913.1,
    "portfolio_roi": 0.0,
    "qqq_price": 588.59,
    "qqq_roi": 0.0,
    "qqq_value": 9913.04,
    "buy_hold_value": 9913.04,
    "buy_hold_roi": 0.0,
    "alpha": 0.0,
    "alpha_dollars": 0.06,
    "ladder_alpha": 0.0,
    "ladder_value_added": 0.06,
    "status": "Beating"
  },
  {
    "date": "2026-04-08",
    "portfolio_value": 10402.5,
    "portfolio_roi": 4.94,
    "qqq_price": 606.09,
    "qqq_roi": 2.97,
    "qqq_value": 10207.78,
    "buy_hold_value": 9913.04,
    "buy_hold_roi": 0.0,
    "alpha": 1.96,
    "alpha_dollars": 194.72,
    "ladder_alpha": 4.94,
    "ladder_value_added": 489.46,
    "status": "Beating"
  },
  {
    "date": "2026-04-09",
    "portfolio_value": 10402.48,
    "portfolio_roi": 4.94,
    "qqq_price": 610.19,
    "qqq_roi": 3.67,
    "qqq_value": 10276.83,
    "buy_hold_value": 9913.04,
    "buy_hold_roi": 0.0,
    "alpha": 1.27,
    "alpha_dollars": 125.66,
    "ladder_alpha": 4.94,
    "ladder_value_added": 489.44,
    "status": "Beating"
  },
  {
    "date": "2026-04-10",
    "portfolio_value": 10402.48,
    "portfolio_roi": 4.94,
    "qqq_price": 611.07,
    "qqq_roi": 3.82,
    "qqq_value": 10291.65,
    "buy_hold_value": 9913.04,
    "buy_hold_roi": 0.0,
    "alpha": 1.12,
    "alpha_dollars": 110.84,
    "ladder_alpha": 4.94,
    "ladder_value_added": 489.44,
    "status": "Beating"
  },
  {
    "date": "2026-04-13",
    "portfolio_value": 10402.48,
    "portfolio_roi": 4.94,
    "qqq_price": 617.39,
    "qqq_roi": 4.89,
    "qqq_value": 10398.09,
    "buy_hold_value": 9913.04,
    "buy_hold_roi": 0.0,
    "alpha": 0.04,
    "alpha_dollars": 4.39,
    "ladder_alpha": 4.94,
    "ladder_value_added": 489.44,
    "status": "Beating"
  },
  {
    "date": "2026-04-14",
    "portfolio_value": 10402.48,
    "portfolio_roi": 4.94,
    "qqq_price": 628.6,
    "qqq_roi": 6.8,
    "qqq_value": 10586.89,
    "buy_hold_value": 9913.04,
    "buy_hold_roi": 0.0,
    "alpha": -1.86,
    "alpha_dollars": -184.41,
    "ladder_alpha": 4.94,
    "ladder_value_added": 489.44,
    "status": "Lagging"
  },
  {
    "date": "2026-04-15",
    "portfolio_value": 10363.78,
    "portfolio_roi": 4.55,
    "qqq_price": 637.4,
    "qqq_roi": 8.29,
    "qqq_value": 10735.1,
    "buy_hold_value": 9913.04,
    "buy_hold_roi": 0.0,
    "alpha": -3.75,
    "alpha_dollars": -371.32,
    "ladder_alpha": 4.55,
    "ladder_value_added": 450.74,
    "status": "Lagging"
  },
  {
    "date": "2026-04-16",
    "portfolio_value": 10363.78,
    "portfolio_roi": 4.55,
    "qqq_price": 640.47,
    "qqq_roi": 8.81,
    "qqq_value": 10786.8,
    "buy_hold_value": 9913.04,
    "buy_hold_roi": 0.0,
    "alpha": -4.27,
    "alpha_dollars": -423.03,
    "ladder_alpha": 4.55,
    "ladder_value_added": 450.74,
    "status": "Lagging"
  },
  {
    "date": "2026-04-17",
    "portfolio_value": 10363.78,
    "portfolio_roi": 4.55,
    "qqq_price": 648.85,
    "qqq_roi": 10.24,
    "qqq_value": 10927.94,
    "buy_hold_value": 9913.04,
    "buy_hold_roi": 0.0,
    "alpha": -5.69,
    "alpha_dollars": -564.16,
    "ladder_alpha": 4.55,
    "ladder_value_added": 450.74,
    "status": "Lagging"
  },
  {
    "date": "2026-04-20",
    "portfolio_value": 10363.78,
    "portfolio_roi": 4.55,
    "qqq_price": 646.79,
    "qqq_roi": 9.89,
    "qqq_value": 10893.25,
    "buy_hold_value": 9913.04,
    "buy_hold_roi": 0.0,
    "alpha": -5.34,
    "alpha_dollars": -529.47,
    "ladder_alpha": 4.55,
    "ladder_value_added": 450.74,
    "status": "Lagging"
  },
  {
    "date": "2026-04-21",
    "portfolio_value": 10369.79,
    "portfolio_roi": 4.61,
    "qqq_price": 644.33,
    "qqq_roi": 9.47,
    "qqq_value": 10851.81,
    "buy_hold_value": 9913.04,
    "buy_hold_roi": 0.0,
    "alpha": -4.86,
    "alpha_dollars": -482.02,
    "ladder_alpha": 4.61,
    "ladder_value_added": 456.75,
    "status": "Lagging"
  },
  {
    "date": "2026-04-22",
    "portfolio_value": 10369.79,
    "portfolio_roi": 4.61,
    "qqq_price": 655.11,
    "qqq_roi": 11.3,
    "qqq_value": 11033.37,
    "buy_hold_value": 9913.04,
    "buy_hold_roi": 0.0,
    "alpha": -6.69,
    "alpha_dollars": -663.58,
    "ladder_alpha": 4.61,
    "ladder_value_added": 456.75,
    "status": "Lagging"
  },
  {
    "date": "2026-04-23",
    "portfolio_value": 10874.85,
    "portfolio_roi": 9.7,
    "qqq_price": 651.42,
    "qqq_roi": 10.67,
    "qqq_value": 10971.22,
    "buy_hold_value": 10181.62,
    "buy_hold_roi": 2.71,
    "alpha": -0.97,
    "alpha_dollars": -96.37,
    "ladder_alpha": 6.99,
    "ladder_value_added": 693.23,
    "status": "Lagging"
  },
  {
    "date": "2026-04-24",
    "portfolio_value": 10851.07,
    "portfolio_roi": 9.46,
    "qqq_price": 663.88,
    "qqq_roi": 12.79,
    "qqq_value": 11181.08,
    "buy_hold_value": 10181.62,
    "buy_hold_roi": 2.71,
    "alpha": -3.33,
    "alpha_dollars": -330.0,
    "ladder_alpha": 6.75,
    "ladder_value_added": 669.46,
    "status": "Lagging"
  },
  {
    "date": "2026-04-27",
    "portfolio_value": 11120.62,
    "portfolio_roi": 12.18,
    "qqq_price": 664.23,
    "qqq_roi": 12.85,
    "qqq_value": 11186.97,
    "buy_hold_value": 10263.88,
    "buy_hold_roi": 3.54,
    "alpha": -0.67,
    "alpha_dollars": -66.35,
    "ladder_alpha": 8.64,
    "ladder_value_added": 856.74,
    "status": "Lagging"
  },
  {
    "date": "2026-04-28",
    "portfolio_value": 11012.34,
    "portfolio_roi": 11.09,
    "qqq_price": 657.55,
    "qqq_roi": 11.72,
    "qqq_value": 11074.47,
    "buy_hold_value": 10263.88,
    "buy_hold_roi": 3.54,
    "alpha": -0.63,
    "alpha_dollars": -62.12,
    "ladder_alpha": 7.55,
    "ladder_value_added": 748.46,
    "status": "Lagging"
  },
  {
    "date": "2026-04-29",
    "portfolio_value": 11018.5,
    "portfolio_roi": 11.15,
    "qqq_price": 661.57,
    "qqq_roi": 12.4,
    "qqq_value": 11142.17,
    "buy_hold_value": 10279.3,
    "buy_hold_roi": 3.69,
    "alpha": -1.25,
    "alpha_dollars": -123.67,
    "ladder_alpha": 7.46,
    "ladder_value_added": 739.2,
    "status": "Lagging"
  },
  {
    "date": "2026-04-30",
    "portfolio_value": 11139.5,
    "portfolio_roi": 12.37,
    "qqq_price": 667.74,
    "qqq_roi": 13.45,
    "qqq_value": 11246.09,
    "buy_hold_value": 10287.55,
    "buy_hold_roi": 3.78,
    "alpha": -1.08,
    "alpha_dollars": -106.58,
    "ladder_alpha": 8.59,
    "ladder_value_added": 851.95,
    "status": "Lagging"
  },
  {
    "date": "2026-05-01",
    "portfolio_value": 11123.65,
    "portfolio_roi": 12.21,
    "qqq_price": 674.15,
    "qqq_roi": 14.54,
    "qqq_value": 11354.04,
    "buy_hold_value": 10215.46,
    "buy_hold_roi": 3.05,
    "alpha": -2.32,
    "alpha_dollars": -230.39,
    "ladder_alpha": 9.16,
    "ladder_value_added": 908.19,
    "status": "Lagging"
  },
  {
    "date": "2026-05-04",
    "portfolio_value": 11154.04,
    "portfolio_roi": 12.52,
    "qqq_price": 672.88,
    "qqq_roi": 14.32,
    "qqq_value": 11332.65,
    "buy_hold_value": 10205.01,
    "buy_hold_roi": 2.95,
    "alpha": -1.8,
    "alpha_dollars": -178.61,
    "ladder_alpha": 9.57,
    "ladder_value_added": 949.03,
    "status": "Lagging"
  },
  {
    "date": "2026-05-05",
    "portfolio_value": 11299.13,
    "portfolio_roi": 13.98,
    "qqq_price": 681.61,
    "qqq_roi": 15.8,
    "qqq_value": 11479.68,
    "buy_hold_value": 10205.01,
    "buy_hold_roi": 2.95,
    "alpha": -1.82,
    "alpha_dollars": -180.55,
    "ladder_alpha": 11.04,
    "ladder_value_added": 1094.12,
    "status": "Lagging"
  },
  {
    "date": "2026-05-06",
    "portfolio_value": 11475.65,
    "portfolio_roi": 15.76,
    "qqq_price": 695.77,
    "qqq_roi": 18.21,
    "qqq_value": 11718.17,
    "buy_hold_value": 10331.45,
    "buy_hold_roi": 4.22,
    "alpha": -2.45,
    "alpha_dollars": -242.52,
    "ladder_alpha": 11.54,
    "ladder_value_added": 1144.2,
    "status": "Lagging"
  },
  {
    "date": "2026-05-07",
    "portfolio_value": 11433.75,
    "portfolio_roi": 15.34,
    "qqq_price": 694.94,
    "qqq_roi": 18.07,
    "qqq_value": 11704.19,
    "buy_hold_value": 10122.93,
    "buy_hold_roi": 2.12,
    "alpha": -2.73,
    "alpha_dollars": -270.44,
    "ladder_alpha": 13.22,
    "ladder_value_added": 1310.82,
    "status": "Lagging"
  },
  {
    "date": "2026-05-08",
    "portfolio_value": 11629.74,
    "portfolio_roi": 17.32,
    "qqq_price": 711.23,
    "qqq_roi": 20.84,
    "qqq_value": 11978.54,
    "buy_hold_value": 10207.23,
    "buy_hold_roi": 2.97,
    "alpha": -3.52,
    "alpha_dollars": -348.81,
    "ladder_alpha": 14.35,
    "ladder_value_added": 1422.51,
    "status": "Lagging"
  },
  {
    "date": "2026-05-11",
    "portfolio_value": 11652.55,
    "portfolio_roi": 17.55,
    "qqq_price": 713.29,
    "qqq_roi": 21.19,
    "qqq_value": 12013.24,
    "buy_hold_value": 10213.44,
    "buy_hold_roi": 3.03,
    "alpha": -3.64,
    "alpha_dollars": -360.69,
    "ladder_alpha": 14.52,
    "ladder_value_added": 1439.1,
    "status": "Lagging"
  },
  {
    "date": "2026-05-12",
    "portfolio_value": 11578.15,
    "portfolio_roi": 16.8,
    "qqq_price": 707.24,
    "qqq_roi": 20.16,
    "qqq_value": 11911.34,
    "buy_hold_value": 10143.95,
    "buy_hold_roi": 2.33,
    "alpha": -3.36,
    "alpha_dollars": -333.2,
    "ladder_alpha": 14.47,
    "ladder_value_added": 1434.2,
    "status": "Lagging"
  },
  {
    "date": "2026-05-13",
    "portfolio_value": 11664.25,
    "portfolio_roi": 17.67,
    "qqq_price": 714.71,
    "qqq_roi": 21.43,
    "qqq_value": 12037.15,
    "buy_hold_value": 10143.95,
    "buy_hold_roi": 2.33,
    "alpha": -3.76,
    "alpha_dollars": -372.91,
    "ladder_alpha": 15.34,
    "ladder_value_added": 1520.3,
    "status": "Lagging"
  },
  {
    "date": "2026-05-14",
    "portfolio_value": 11844.63,
    "portfolio_roi": 19.49,
    "qqq_price": 719.79,
    "qqq_roi": 22.29,
    "qqq_value": 12122.71,
    "buy_hold_value": 10270.5,
    "buy_hold_roi": 3.61,
    "alpha": -2.81,
    "alpha_dollars": -278.08,
    "ladder_alpha": 15.88,
    "ladder_value_added": 1574.13,
    "status": "Lagging"
  },
  {
    "date": "2026-05-15",
    "portfolio_value": 11807.91,
    "portfolio_roi": 19.11,
    "qqq_price": 708.93,
    "qqq_roi": 20.45,
    "qqq_value": 11939.81,
    "buy_hold_value": 10196.63,
    "buy_hold_roi": 2.86,
    "alpha": -1.33,
    "alpha_dollars": -131.9,
    "ladder_alpha": 16.25,
    "ladder_value_added": 1611.28,
    "status": "Lagging"
  },
  {
    "date": "2026-05-18",
    "portfolio_value": 11784.71,
    "portfolio_roi": 18.88,
    "qqq_price": 705.88,
    "qqq_roi": 19.93,
    "qqq_value": 11888.44,
    "buy_hold_value": 10165.02,
    "buy_hold_roi": 2.54,
    "alpha": -1.05,
    "alpha_dollars": -103.73,
    "ladder_alpha": 16.34,
    "ladder_value_added": 1619.69,
    "status": "Lagging"
  },
  {
    "date": "2026-05-19",
    "portfolio_value": 11679.97,
    "portfolio_roi": 17.82,
    "qqq_price": 701.53,
    "qqq_roi": 19.19,
    "qqq_value": 11815.18,
    "buy_hold_value": 10031.92,
    "buy_hold_roi": 1.2,
    "alpha": -1.36,
    "alpha_dollars": -135.21,
    "ladder_alpha": 16.63,
    "ladder_value_added": 1648.05,
    "status": "Lagging"
  },
  {
    "date": "2026-05-20",
    "portfolio_value": 11731.9,
    "portfolio_roi": 18.35,
    "qqq_price": 713.15,
    "qqq_roi": 21.16,
    "qqq_value": 12010.88,
    "buy_hold_value": 10031.92,
    "buy_hold_roi": 1.2,
    "alpha": -2.81,
    "alpha_dollars": -278.99,
    "ladder_alpha": 17.15,
    "ladder_value_added": 1699.97,
    "status": "Lagging"
  },
  {
    "date": "2026-05-21",
    "portfolio_value": 11887.59,
    "portfolio_roi": 19.92,
    "qqq_price": 714.51,
    "qqq_roi": 21.39,
    "qqq_value": 12033.79,
    "buy_hold_value": 10122.38,
    "buy_hold_roi": 2.11,
    "alpha": -1.47,
    "alpha_dollars": -146.2,
    "ladder_alpha": 17.81,
    "ladder_value_added": 1765.21,
    "status": "Lagging"
  },
  {
    "date": "2026-05-22",
    "portfolio_value": 11936.65,
    "portfolio_roi": 20.41,
    "qqq_price": 717.54,
    "qqq_roi": 21.91,
    "qqq_value": 12084.82,
    "buy_hold_value": 10154.08,
    "buy_hold_roi": 2.43,
    "alpha": -1.49,
    "alpha_dollars": -148.17,
    "ladder_alpha": 17.98,
    "ladder_value_added": 1782.57,
    "status": "Lagging"
  },
  {
    "date": "2026-05-26",
    "portfolio_value": 11916.74,
    "portfolio_roi": 20.21,
    "qqq_price": 730.28,
    "qqq_roi": 24.07,
    "qqq_value": 12299.38,
    "buy_hold_value": 10125.15,
    "buy_hold_roi": 2.14,
    "alpha": -3.86,
    "alpha_dollars": -382.65,
    "ladder_alpha": 18.07,
    "ladder_value_added": 1791.59,
    "status": "Lagging"
  },
  {
    "date": "2026-05-27",
    "portfolio_value": 11931.47,
    "portfolio_roi": 20.36,
    "qqq_price": 729.45,
    "qqq_roi": 23.93,
    "qqq_value": 12285.41,
    "buy_hold_value": 10075.83,
    "buy_hold_roi": 1.64,
    "alpha": -3.57,
    "alpha_dollars": -353.93,
    "ladder_alpha": 18.72,
    "ladder_value_added": 1855.64,
    "status": "Lagging"
  },
  {
    "date": "2026-05-28",
    "portfolio_value": 11935.19,
    "portfolio_roi": 20.4,
    "qqq_price": 735.6,
    "qqq_roi": 24.98,
    "qqq_value": 12388.98,
    "buy_hold_value": 10048.33,
    "buy_hold_roi": 1.36,
    "alpha": -4.58,
    "alpha_dollars": -453.79,
    "ladder_alpha": 19.03,
    "ladder_value_added": 1886.86,
    "status": "Lagging"
  },
  {
    "date": "2026-05-29",
    "portfolio_value": 12061.58,
    "portfolio_roi": 21.67,
    "qqq_price": 738.31,
    "qqq_roi": 25.44,
    "qqq_value": 12434.63,
    "buy_hold_value": 10128.04,
    "buy_hold_roi": 2.17,
    "alpha": -3.76,
    "alpha_dollars": -373.04,
    "ladder_alpha": 19.51,
    "ladder_value_added": 1933.54,
    "status": "Lagging"
  },
  {
    "date": "2026-06-01",
    "portfolio_value": 12464.16,
    "portfolio_roi": 25.74,
    "qqq_price": 742.74,
    "qqq_roi": 26.19,
    "qqq_value": 12509.24,
    "buy_hold_value": 10311.16,
    "buy_hold_roi": 4.02,
    "alpha": -0.45,
    "alpha_dollars": -45.07,
    "ladder_alpha": 21.72,
    "ladder_value_added": 2153.01,
    "status": "Lagging"
  },
  {
    "date": "2026-06-02",
    "portfolio_value": 12546.74,
    "portfolio_roi": 26.57,
    "qqq_price": 746.16,
    "qqq_roi": 26.77,
    "qqq_value": 12566.84,
    "buy_hold_value": 10428.52,
    "buy_hold_roi": 5.2,
    "alpha": -0.2,
    "alpha_dollars": -20.1,
    "ladder_alpha": 21.37,
    "ladder_value_added": 2118.22,
    "status": "Lagging"
  },
  {
    "date": "2026-06-03",
    "portfolio_value": 12482.17,
    "portfolio_roi": 25.92,
    "qqq_price": 744.21,
    "qqq_roi": 26.44,
    "qqq_value": 12533.99,
    "buy_hold_value": 10301.07,
    "buy_hold_roi": 3.91,
    "alpha": -0.52,
    "alpha_dollars": -51.82,
    "ladder_alpha": 22.0,
    "ladder_value_added": 2181.11,
    "status": "Lagging"
  },
  {
    "date": "2026-06-04",
    "portfolio_value": 12158.12,
    "portfolio_roi": 22.65,
    "qqq_price": 740.61,
    "qqq_roi": 25.83,
    "qqq_value": 12473.36,
    "buy_hold_value": 10198.75,
    "buy_hold_roi": 2.88,
    "alpha": -3.18,
    "alpha_dollars": -315.24,
    "ladder_alpha": 19.77,
    "ladder_value_added": 1959.37,
    "status": "Lagging"
  },
  {
    "date": "2026-06-05",
    "portfolio_value": 12237.03,
    "portfolio_roi": 23.44,
    "qqq_price": 705.06,
    "qqq_roi": 19.79,
    "qqq_value": 11874.63,
    "buy_hold_value": 10219.83,
    "buy_hold_roi": 3.09,
    "alpha": 3.66,
    "alpha_dollars": 362.4,
    "ladder_alpha": 20.35,
    "ladder_value_added": 2017.2,
    "status": "Beating"
  },
  {
    "date": "2026-06-08",
    "portfolio_value": 12204.33,
    "portfolio_roi": 23.11,
    "qqq_price": 716.07,
    "qqq_roi": 21.66,
    "qqq_value": 12060.06,
    "buy_hold_value": 10219.83,
    "buy_hold_roi": 3.09,
    "alpha": 1.46,
    "alpha_dollars": 144.27,
    "ladder_alpha": 20.02,
    "ladder_value_added": 1984.5,
    "status": "Beating"
  },
  {
    "date": "2026-06-09",
    "portfolio_value": 11896.84,
    "portfolio_roi": 20.01,
    "qqq_price": 707.83,
    "qqq_roi": 20.26,
    "qqq_value": 11921.28,
    "buy_hold_value": 9956.78,
    "buy_hold_roi": 0.44,
    "alpha": -0.25,
    "alpha_dollars": -24.45,
    "ladder_alpha": 19.57,
    "ladder_value_added": 1940.05,
    "status": "Lagging"
  },
  {
    "date": "2026-06-10",
    "portfolio_value": 11705.36,
    "portfolio_roi": 18.08,
    "qqq_price": 693.69,
    "qqq_roi": 17.86,
    "qqq_value": 11683.14,
    "buy_hold_value": 9956.78,
    "buy_hold_roi": 0.44,
    "alpha": 0.22,
    "alpha_dollars": 22.22,
    "ladder_alpha": 17.64,
    "ladder_value_added": 1748.57,
    "status": "Beating"
  },
  {
    "date": "2026-06-11",
    "portfolio_value": 11705.36,
    "portfolio_roi": 18.08,
    "qqq_price": 717.12,
    "qqq_roi": 21.84,
    "qqq_value": 12077.74,
    "buy_hold_value": 9956.78,
    "buy_hold_roi": 0.44,
    "alpha": -3.76,
    "alpha_dollars": -372.39,
    "ladder_alpha": 17.64,
    "ladder_value_added": 1748.57,
    "status": "Lagging"
  },
  {
    "date": "2026-06-12",
    "portfolio_value": 11799.69,
    "portfolio_roi": 19.03,
    "qqq_price": 721.34,
    "qqq_roi": 22.55,
    "qqq_value": 12148.82,
    "buy_hold_value": 10060.97,
    "buy_hold_roi": 1.49,
    "alpha": -3.52,
    "alpha_dollars": -349.12,
    "ladder_alpha": 17.54,
    "ladder_value_added": 1738.72,
    "status": "Lagging"
  },
  {
    "date": "2026-06-15",
    "portfolio_value": 12039.39,
    "portfolio_roi": 21.45,
    "qqq_price": 744.0,
    "qqq_roi": 26.4,
    "qqq_value": 12530.46,
    "buy_hold_value": 10067.64,
    "buy_hold_roi": 1.56,
    "alpha": -4.95,
    "alpha_dollars": -491.07,
    "ladder_alpha": 19.89,
    "ladder_value_added": 1971.75,
    "status": "Lagging"
  },
  {
    "date": "2026-06-16",
    "portfolio_value": 12136.81,
    "portfolio_roi": 22.43,
    "qqq_price": 729.86,
    "qqq_roi": 24.0,
    "qqq_value": 12292.31,
    "buy_hold_value": 10109.79,
    "buy_hold_roi": 1.98,
    "alpha": -1.57,
    "alpha_dollars": -155.5,
    "ladder_alpha": 20.45,
    "ladder_value_added": 2027.02,
    "status": "Lagging"
  },
  {
    "date": "2026-06-17",
    "portfolio_value": 12136.91,
    "portfolio_roi": 22.43,
    "qqq_price": 722.51,
    "qqq_roi": 22.75,
    "qqq_value": 12168.52,
    "buy_hold_value": 10144.8,
    "buy_hold_roi": 2.34,
    "alpha": -0.32,
    "alpha_dollars": -31.62,
    "ladder_alpha": 20.1,
    "ladder_value_added": 1992.11,
    "status": "Lagging"
  },
  {
    "date": "2026-06-18",
    "portfolio_value": 12254.91,
    "portfolio_roi": 23.62,
    "qqq_price": 740.62,
    "qqq_roi": 25.83,
    "qqq_value": 12473.53,
    "buy_hold_value": 10148.27,
    "buy_hold_roi": 2.37,
    "alpha": -2.21,
    "alpha_dollars": -218.63,
    "ladder_alpha": 21.25,
    "ladder_value_added": 2106.64,
    "status": "Lagging"
  },
  {
    "date": "2026-06-22",
    "portfolio_value": 12346.84,
    "portfolio_roi": 24.55,
    "qqq_price": 737.95,
    "qqq_roi": 25.38,
    "qqq_value": 12428.56,
    "buy_hold_value": 10148.27,
    "buy_hold_roi": 2.37,
    "alpha": -0.82,
    "alpha_dollars": -81.73,
    "ladder_alpha": 22.18,
    "ladder_value_added": 2198.57,
    "status": "Lagging"
  },
  {
    "date": "2026-06-23",
    "portfolio_value": 11977.71,
    "portfolio_roi": 20.83,
    "qqq_price": 713.65,
    "qqq_roi": 21.25,
    "qqq_value": 12019.3,
    "buy_hold_value": 10034.13,
    "buy_hold_roi": 1.22,
    "alpha": -0.42,
    "alpha_dollars": -41.6,
    "ladder_alpha": 19.61,
    "ladder_value_added": 1943.57,
    "status": "Lagging"
  },
  {
    "date": "2026-06-24",
    "portfolio_value": 12001.66,
    "portfolio_roi": 21.07,
    "qqq_price": 710.62,
    "qqq_roi": 20.73,
    "qqq_value": 11968.27,
    "buy_hold_value": 10039.9,
    "buy_hold_roi": 1.28,
    "alpha": 0.34,
    "alpha_dollars": 33.39,
    "ladder_alpha": 19.79,
    "ladder_value_added": 1961.76,
    "status": "Beating"
  },
  {
    "date": "2026-06-25",
    "portfolio_value": 11761.88,
    "portfolio_roi": 18.65,
    "qqq_price": 716.38,
    "qqq_roi": 21.71,
    "qqq_value": 12065.28,
    "buy_hold_value": 9958.96,
    "buy_hold_roi": 0.46,
    "alpha": -3.06,
    "alpha_dollars": -303.4,
    "ladder_alpha": 18.19,
    "ladder_value_added": 1802.93,
    "status": "Lagging"
  },
  {
    "date": "2026-06-26",
    "portfolio_value": 11645.91,
    "portfolio_roi": 17.48,
    "qqq_price": 706.52,
    "qqq_roi": 20.04,
    "qqq_value": 11899.22,
    "buy_hold_value": 9909.92,
    "buy_hold_roi": -0.03,
    "alpha": -2.56,
    "alpha_dollars": -253.31,
    "ladder_alpha": 17.51,
    "ladder_value_added": 1735.99,
    "status": "Lagging"
  },
  {
    "date": "2026-06-29",
    "portfolio_value": 11831.59,
    "portfolio_roi": 19.35,
    "qqq_price": 724.08,
    "qqq_roi": 23.02,
    "qqq_value": 12194.96,
    "buy_hold_value": 9945.06,
    "buy_hold_roi": 0.32,
    "alpha": -3.67,
    "alpha_dollars": -363.37,
    "ladder_alpha": 19.03,
    "ladder_value_added": 1886.53,
    "status": "Lagging"
  },
  {
    "date": "2026-06-30",
    "portfolio_value": 11888.94,
    "portfolio_roi": 19.93,
    "qqq_price": 736.4,
    "qqq_roi": 25.11,
    "qqq_value": 12402.46,
    "buy_hold_value": 9993.69,
    "buy_hold_roi": 0.81,
    "alpha": -5.18,
    "alpha_dollars": -513.52,
    "ladder_alpha": 19.12,
    "ladder_value_added": 1895.25,
    "status": "Lagging"
  },
  {
    "date": "2026-07-01",
    "portfolio_value": 11956.4,
    "portfolio_roi": 20.61,
    "qqq_price": 725.17,
    "qqq_roi": 23.2,
    "qqq_value": 12213.32,
    "buy_hold_value": 9949.35,
    "buy_hold_roi": 0.37,
    "alpha": -2.59,
    "alpha_dollars": -256.92,
    "ladder_alpha": 20.25,
    "ladder_value_added": 2007.05,
    "status": "Lagging"
  },
  {
    "date": "2026-07-02",
    "portfolio_value": 11910.94,
    "portfolio_roi": 20.15,
    "qqq_price": 712.6,
    "qqq_roi": 21.07,
    "qqq_value": 12001.62,
    "buy_hold_value": 9804.68,
    "buy_hold_roi": -1.09,
    "alpha": -0.91,
    "alpha_dollars": -90.68,
    "ladder_alpha": 21.25,
    "ladder_value_added": 2106.26,
    "status": "Lagging"
  },
  {
    "date": "2026-07-06",
    "portfolio_value": 11995.71,
    "portfolio_roi": 21.01,
    "qqq_price": 722.82,
    "qqq_roi": 22.81,
    "qqq_value": 12173.74,
    "buy_hold_value": 9847.86,
    "buy_hold_roi": -0.66,
    "alpha": -1.8,
    "alpha_dollars": -178.03,
    "ladder_alpha": 21.67,
    "ladder_value_added": 2147.85,
    "status": "Lagging"
  },
  {
    "date": "2026-07-07",
    "portfolio_value": 11964.03,
    "portfolio_roi": 20.69,
    "qqq_price": 709.43,
    "qqq_roi": 20.53,
    "qqq_value": 11948.23,
    "buy_hold_value": 9860.54,
    "buy_hold_roi": -0.53,
    "alpha": 0.16,
    "alpha_dollars": 15.8,
    "ladder_alpha": 21.22,
    "ladder_value_added": 2103.49,
    "status": "Beating"
  },
  {
    "date": "2026-07-08",
    "portfolio_value": 12203.13,
    "portfolio_roi": 23.1,
    "qqq_price": 711.44,
    "qqq_roi": 20.87,
    "qqq_value": 11982.08,
    "buy_hold_value": 9928.38,
    "buy_hold_roi": 0.15,
    "alpha": 2.23,
    "alpha_dollars": 221.05,
    "ladder_alpha": 22.95,
    "ladder_value_added": 2274.75,
    "status": "Beating"
  },
  {
    "date": "2026-07-09",
    "portfolio_value": 13017.99,
    "portfolio_roi": 31.32,
    "qqq_price": 723.28,
    "qqq_roi": 22.88,
    "qqq_value": 12181.49,
    "buy_hold_value": 10093.61,
    "buy_hold_roi": 1.82,
    "alpha": 8.44,
    "alpha_dollars": 836.5,
    "ladder_alpha": 29.5,
    "ladder_value_added": 2924.38,
    "status": "Beating"
  }
]

# Refresh QQQ through the latest completed market session.
# yfinance treats `end` as exclusive, so using today's date intentionally stops at T-1.
def refresh_qqq_history(benchmark):
    start_date = benchmark.get('start_date', '2026-04-07')
    symbol = benchmark.get('symbol', 'QQQ')
    end_exclusive = datetime.now().strftime('%Y-%m-%d')

    # Primary source: Yahoo Finance chart endpoint, using only Python's standard library.
    try:
        import urllib.parse
        import urllib.request
        start_epoch = int(datetime.strptime(start_date, '%Y-%m-%d').timestamp())
        end_epoch = int(datetime.strptime(end_exclusive, '%Y-%m-%d').timestamp())
        url = (
            f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(symbol)}"
            f"?period1={start_epoch}&period2={end_epoch}&interval=1d&events=history"
        )
        request = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 LadderIQ/1.0'})
        with urllib.request.urlopen(request, timeout=20) as response:
            payload = json.loads(response.read().decode('utf-8'))
        result = payload['chart']['result'][0]
        timestamps = result.get('timestamp') or []
        quotes = result.get('indicators', {}).get('quote', [{}])[0]
        closes = quotes.get('close') or []
        series = []
        for timestamp, value in zip(timestamps, closes):
            if value is None:
                continue
            market_date = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d')
            series.append({'date': market_date, 'price': round(float(value), 4)})
        if not series:
            raise RuntimeError('Yahoo Finance returned no QQQ closes.')
        benchmark['series'] = series
        print(f"QQQ benchmark refreshed through {series[-1]['date']} from Yahoo Finance.")
        return series[-1]['date'], series[-1]['price']
    except Exception as yahoo_exc:
        print(f'WARNING: Direct Yahoo Finance refresh failed. {yahoo_exc}')

    # Secondary source: yfinance, when installed.
    try:
        import yfinance as yf
        history = yf.download(
            symbol,
            start=start_date,
            end=end_exclusive,
            progress=False,
            auto_adjust=False,
            threads=False,
        )
        if history is None or history.empty:
            raise RuntimeError('yfinance returned no QQQ history.')
        close = history['Close']
        if hasattr(close, 'columns'):
            close = close.iloc[:, 0]
        close = close.dropna()
        if close.empty:
            raise RuntimeError('QQQ close series was empty.')
        benchmark['series'] = [
            {'date': idx.strftime('%Y-%m-%d'), 'price': round(float(value), 4)}
            for idx, value in close.items()
        ]
        print(f"QQQ benchmark refreshed through {benchmark['series'][-1]['date']} using yfinance.")
        return benchmark['series'][-1]['date'], benchmark['series'][-1]['price']
    except Exception as yf_exc:
        print(f'WARNING: yfinance refresh failed; using embedded benchmark data. {yf_exc}')
        existing = benchmark.get('series') or []
        if existing:
            last = existing[-1]
            return last['date'], float(last['price'])
        return benchmark.get('end_date', '2026-07-10'), float(benchmark.get('end_price', 725.54))

QQQ_END_DATE, QQQ_END_PRICE = refresh_qqq_history(QQQ_BENCHMARK)
qqq_twr=((QQQ_END_PRICE/QQQ_BENCHMARK['start_price'])-1)*100
benchmark_row={
    'date':QQQ_END_DATE,
    'portfolio_value':round(account_total,2),
    'portfolio_roi':round(twr,4),
    'personal_roi':round(personal_roi,4),
    'qqq_price':QQQ_END_PRICE,
    'qqq_roi':round(qqq_twr,4),
    'qqq_value':round(BASELINE*(1+qqq_twr/100),2),
    'buy_hold_value':round(BASELINE*(1+QQQ_BENCHMARK.get('buy_hold_return_pct',0)/100),2),
    'buy_hold_roi':round(QQQ_BENCHMARK.get('buy_hold_return_pct',0),4),
    'alpha':round(twr-qqq_twr,4),
    'alpha_dollars':round(BASELINE*((twr-qqq_twr)/100),2),
    'ladder_alpha':round(twr-QQQ_BENCHMARK.get('buy_hold_return_pct',0),4),
    'ladder_value_added':round(BASELINE*((twr-QQQ_BENCHMARK.get('buy_hold_return_pct',0))/100),2),
    'status':'Beating' if twr>=qqq_twr else 'Lagging'
}
QQQ_BENCHMARK['replay_series']=[
    r for r in QQQ_BENCHMARK.get('replay_series',[]) if r.get('date') != QQQ_END_DATE
] + [benchmark_row]
QQQ_BENCHMARK['replay_series'].sort(key=lambda row: row.get('date',''))
QQQ_BENCHMARK.update({
    'end_date':QQQ_END_DATE,'end_price':QQQ_END_PRICE,'return_pct':qqq_twr,
    'portfolio_return_pct':twr,'personal_roi_pct':personal_roi,
    'alpha_pct':twr-qqq_twr,'status':benchmark_row['status'],
    'capital_ledger':capital_ledger,
    'notes':'QQQ history refreshes from Yahoo Finance through the latest completed market session each time the build runs.'
})

# Stock-specific ladder generation.
# BR-017 — Active Position Rule:
# A sell ladder is generated only when the imported position has both a
# meaningful share quantity and market value. This removes stale/zero-share
# exit ladders while preserving legitimate fractional-share positions.
MIN_ACTIVE_POSITION_SHARES = 0.0005
MIN_ACTIVE_POSITION_VALUE = 1.00

def has_active_position(stock):
    try:
        qty = max(0.0, float(stock.get('quantity') or 0))
        value = max(0.0, float(stock.get('value') or 0))
    except (TypeError, ValueError):
        return False
    return qty >= MIN_ACTIVE_POSITION_SHARES and value >= MIN_ACTIVE_POSITION_VALUE

def resolve_lifecycle_state(stock):
    sym=stock.get('symbol')
    if has_active_position(stock):
        return 'owned'
    override=(lifecycle.get('symbols') or {}).get(sym, {})
    if override.get('manual') and override.get('state') in {'active_candidate','watchlist','recently_exited','archived'}:
        # A qualifying score can promote a stale watch-only override into the
        # candidate pipeline without creating an automatic buy ladder.
        if override.get('state') == 'watchlist' and float(stock.get('opportunity') or 0) >= 60:
            return 'active_candidate'
        return override['state']
    if stock.get('status') in {'Candidate','Emerging'}:
        return 'active_candidate'
    # Symbols eligible for a fresh buy ladder can remain visible as approved
    # allocation candidates even without a current position. Harvest-only names
    # with no shares are automatically archived.
    if sym not in {'NVDA','AMZN','ARM'} and stock.get('price',0) > 0:
        return 'active_candidate'
    return 'archived'

def lifecycle_visible(stock):
    return stock.get('lifecycle_state') in {'owned','active_candidate','recently_exited'}

def buy_levels(sym, price):
    if price<=0: return []
    if sym in SPECIAL_SITUATION_SYMBOLS:
        return [('Buy Zone 1', round(price*.97,2), 'Add only on weakness'),('Buy Zone 2', round(price*.92,2), 'Strong add zone'),('Review Add', round(price*.85,2), 'Manual review')]
    # BR-078: widen or tighten the entry ladder using observed annualized
    # volatility. Stable stocks use the baseline 1.5/3.5/5.5% pullbacks;
    # highly volatile names receive wider rungs, capped to preserve usability.
    volatility=float((scores.get(sym) or {}).get('annualized_volatility_pct') or 30)
    vol_factor=max(.80,min(1.80,volatility/35.0))
    gaps=[.015*vol_factor,.035*vol_factor,.055*vol_factor]
    return [('First Entry', round(price*(1-gaps[0]),2), 'Volatility-adjusted initial entry'),('Add On', round(price*(1-gaps[1]),2), 'Volatility-adjusted pullback add'),('Final Add', round(price*(1-gaps[2]),2), 'Final add only if thesis remains intact')]

def target_weight_for_score(sym, score, group):
    """Return the current target portfolio weight as a decimal.

    BR-021 Dynamic Allocation Rebalancing: target allocation must be
    recalculated from the latest opportunity score after every imported trade.
    This prevents yesterday's fixed share ladder from surviving a completed
    sale or a material score recovery.
    """
    score=float(score or 0)
    if sym == 'NVDA':
        # NVDA remains a Tactical Compounder. A recovered score supports a
        # larger retained position, while lower scores progressively reduce it.
        if score >= 90: return 0.30
        if score >= 80: return 0.275
        if score >= 70: return 0.25
        if score >= 60: return 0.225
        return 0.20
    return None


def sell_levels(sym, price, qty, avg, position_value=0, opportunity_score=0, portfolio_total=0, group=''):
    # Never create an exit ladder for a closed, missing, or economically
    # meaningless position. Fractional positions remain supported.
    try:
        current_qty = max(0.0, float(qty or 0))
        current_value = max(0.0, float(position_value or 0))
    except (TypeError, ValueError):
        return []
    if current_qty < MIN_ACTIVE_POSITION_SHARES or current_value < MIN_ACTIVE_POSITION_VALUE:
        return []
    if sym=='AMZN':
        q=current_qty
        # Sell ladders must harvest into strength, never below the latest market price.
        # Keep the first rung at least 1.5% above market and the second at least 4% above.
        first=round(price*1.015,2) if price>0 else 249.00
        second=round(price*1.04,2) if price>0 else 255.00
        if float(avg or 0) > 0:
            # BR-084 Universal Profit Floor: even special AMZN harvest rungs
            # must remain above imported average cost basis.
            first=max(first, round(float(avg)*1.01,2))
            second=max(second, round(float(avg)*1.03,2))
        if second <= first:
            second=round(first*1.02,2)
        amzn_q=rounded_split_quantities(q, (.40,.60))
        return [('40% Exit',first,amzn_q[0],'Validated harvest rung above market and cost basis'),('60% Exit',second,amzn_q[1],'Complete exit only into additional profitable strength')]
    if sym in SPECIAL_SITUATION_SYMBOLS:
        cost=avg or price
        return [('+50% Review', round(cost*1.5), current_qty, 'Review only'),('+100% Review', round(cost*2), current_qty, 'Consider capital recovery')]
    if price<=0: return []
    # State-driven exit ladder. BR-084 Universal Profit Floor: every generated
    # sell rung must be profitable versus imported Fidelity average cost basis.
    # Defensive/Recovery states may sell sooner than Hold/Harvest, but never
    # intentionally below average cost.
    temp={'symbol':sym,'opportunity':opportunity_score,'price':price,'avg_cost':avg,'total_pl_pct':0,'score_data':scores.get(sym,{}),'immediate_risk_override':confirmation.get(sym,{}).get('immediate_risk_override',False)}
    state=position_state(temp)['name']
    if state=='Defensive':
        multipliers=(1.005,1.025,1.05); notes=('Defensive review above cost basis','Reduce on profitable recovery','Complete defensive rebalance into profitable strength')
    elif state=='Recovery':
        multipliers=(1.025,1.055,1.09); notes=('Recovery trim above cost basis','Trim into profitable recovery zone','Harvest only if profitable recovery extends')
    elif state=='Harvest':
        multipliers=(1.04,1.08,1.13); notes=('Harvest strength above cost basis','Lock additional gains above cost basis','Final profit-harvest rung')
    else:
        multipliers=(1.03,1.065,1.10); notes=('Management review above cost basis','Trim into strength above cost basis','Extended strength review above cost basis')

    prices=[round(price*m,2) for m in multipliers]
    if float(avg or 0) > 0:
        # BR-084 Universal Profit Floor. Recovery/Defensive ladders may use a
        # tighter profit buffer so they can de-risk sooner, but no automatic
        # sell rung is allowed below imported average cost basis.
        if state == 'Defensive':
            basis_floors=(1.005,1.02,1.04)
        elif state == 'Recovery':
            basis_floors=(1.01,1.03,1.05)
        else:
            basis_floors=(1.02,1.05,1.08)
        prices=[max(prices[i], round(float(avg)*basis_floors[i],2)) for i in range(3)]
        # Rounding or an unusual basis can collapse rungs; maintain strict order.
        for i in range(1,3):
            if prices[i] <= prices[i-1]:
                prices[i]=round(prices[i-1]*1.01,2)

    # BR-081 Maximum Harvest Rule: a profitable strength ladder should be
    # large enough to monetize the move. High opportunity does not suppress
    # selling; it changes how readily the position may later be rebuilt.
    # Hold ladders may harvest 60%, Harvest ladders 80%, Recovery ladders 60%,
    # and Defensive ladders may reduce up to 100% of the current position.
    max_harvest_by_state={
        'Hold':0.60,
        'Harvest':0.80,
        'Recovery':0.60,
        'Defensive':1.00,
    }
    eligible_qty=current_qty*max_harvest_by_state.get(state,0.60)
    splits=(.40,.35,.25)
    rounded_qty=rounded_split_quantities(eligible_qty, splits)
    return [(state+' '+str(i+1),prices[i],rounded_qty[i],notes[i]) for i in range(3)]

def build_shadow_preservation_ladder(stock, capital_shadow):
    """Research-only hypothetical sell ladder. Never consumed by live execution logic."""
    if not stock.get('has_active_position'):
        return {'active': False, 'levels': [], 'reason': 'No active position.'}
    score=capital_shadow.get('score')
    try: score=float(score)
    except Exception: return {'active': False, 'levels': [], 'reason': 'Capital Preservation shadow score is pending.'}
    regime=str(capital_shadow.get('regime') or 'Growth')
    if regime in {'Growth','Caution'}:
        return {'active': False, 'levels': [], 'reason': f'{regime}: live profit-floor ladder remains the hypothetical preference.'}
    price=float(stock.get('price') or 0); qty=float(stock.get('quantity') or 0); avg=float(stock.get('avg_cost') or 0)
    if price<=0 or qty<=0: return {'active': False, 'levels': [], 'reason': 'Price or quantity unavailable.'}
    ops=float(stock.get('final_ops') if stock.get('final_ops') is not None else (stock.get('opportunity') or 0))
    news=float(stock.get('news_adjustment') or 0); trend=str(stock.get('trend') or '')
    stock_risk=(15 if trend=='Down' else 6 if trend=='Lateral' else 0)+(15 if ops<60 else 8 if ops<75 else 0)+(10 if news<=-5 else 0)
    if regime=='Preservation': fraction, mults=.60,(1.01,1.03,1.05)
    elif regime=='Recession': fraction, mults=.80,(1.00,1.02,1.04)
    else: fraction, mults=1.00,(.99,1.00,1.02)
    # Weaker individual positions move one step more urgently inside the macro regime.
    if stock_risk>=25:
        mults=tuple(max(.97,m-.015) for m in mults)
    splits=(.40,.35,.25); eligible=qty*fraction; rounded_shadow_qty=rounded_split_quantities(eligible, splits); levels=[]
    macro_reason=capital_shadow.get('summary') or f'Capital Preservation score {score:.1f} is in {regime}.'
    stock_bits=[]
    if trend in {'Down','Lateral'}: stock_bits.append(f'{trend.lower()} price trend')
    if ops<75: stock_bits.append(f'OPS {ops:.1f}')
    if news<=-5: stock_bits.append(f'negative news impact {news:.1f}')
    stock_reason=', '.join(stock_bits) if stock_bits else 'no exceptional stock-level weakness'
    for i,m in enumerate(mults):
        px=round(price*m,2); sh=rounded_shadow_qty[i]; below=avg>0 and px<avg
        loss_pct=((px/avg)-1)*100 if below else 0
        why=(f'SHADOW ONLY — {regime} capital-preservation scenario. {macro_reason} Position factors: {stock_reason}. ' +
             (f'Below average cost by {abs(loss_pct):.1f}% because preserving capital would override the normal profit floor.' if below else 'This rung remains above average cost.'))
        levels.append({'level':i+1,'price':px,'shares':sh,'trim_pct':sh/qty*100,'proceeds':px*sh,'below_cost':below,'loss_vs_basis_pct':loss_pct,'note':why})
    return {'active': True, 'regime':regime, 'score':score, 'levels':levels, 'reason':macro_reason, 'stock_risk_points':stock_risk}

confirmed_candidate_count=len(confirmed_candidate_symbols)
# BR-072/073: every displayed, non-owned Growth Candidate must have a buy
# ladder. Confirmation controls whether the ladder is ACTIVE or PREVIEW; it no
# longer suppresses the ladder entirely. This lets the user prepare orders for
# emerging opportunities while preserving the two-session confirmation gate.
allocation_candidate_symbols=list(dict.fromkeys(candidate_symbols))
# BR-068/069: allocate the candidate pool by rank, confidence, return velocity
# and sector concentration instead of equal division. The complete candidate
# pool is capped at 85% of deployable cash and each name remains capped at 25%.
sector_weights={}
for held_sym, pos in positions.items():
    sector=(scores.get(held_sym) or {}).get('sector','Unknown')
    sector_weights[sector]=sector_weights.get(sector,0)+float(pos.get('weight') or 0)
_candidate_strength={}
for sym in allocation_candidate_symbols:
    row=scores.get(sym) or {}
    stock_row=next((x for x in stocks if x.get('symbol') == sym), {})
    ops=float(stock_row.get('final_ops') if stock_row.get('final_ops') is not None else (stock_row.get('opportunity') or row.get('composite_score') or row.get('leadership_score') or 0))
    base=max(.01,float(row.get('return_velocity') or 0))*max(.25,float(row.get('reward_to_risk') or 0))*max(.50,float(row.get('business_quality') or stock_row.get('business_quality') or 50)/100)
    concentration=max(0.35,1-min(0.65,sector_weights.get(row.get('sector','Unknown'),0)/100))
    confirmation_factor=1.35 if sym in confirmed_candidate_symbols else max(.55,min(.95,ops/100))
    _candidate_strength[sym]=base*concentration*confirmation_factor
_candidate_strength_total=sum(_candidate_strength.values())

def budget_for(sym, is_owned=False, group='', score=0, current_weight=0):
    if group == 'Growth Candidates':
        if sym not in allocation_candidate_symbols or not allocation_candidate_symbols or _candidate_strength_total<=0:
            return 0.0
        proportional=deployable*.85*(_candidate_strength.get(sym,0)/_candidate_strength_total)
        return min(proportional,deployable*.25)
    # Owned positions may continue accumulating when the current signal is
    # strong. Preserve the established symbol weights and give newly imported
    # approved holdings a conservative default budget rather than suppressing
    # their buy ladder solely because shares are already owned.
    weights={'TSM':.22,'PANW':.20,'ANET':.16,'ASML':.12,'CRWD':.10,'AMD':.10}
    default_weight=.08 if is_owned and float(score or 0) >= 75 else 0
    return deployable*weights.get(sym,default_weight)

def owned_buy_eligible(stock):
    """Return True when an owned position may be accumulated on weakness.

    Ownership and sell management are independent from accumulation. A strong,
    upward-trending position can therefore show both buy and sell ladders. Risk
    states and harvest-only/special-situation names remain sell/hold only.
    """
    if not stock.get('has_active_position'):
        return False
    if stock.get('symbol') in SPECIAL_SITUATION_SYMBOLS:
        return False
    score=float(stock.get('eligibility_ops') if stock.get('eligibility_ops') is not None else (stock.get('opportunity') or 0))
    state=(stock.get('position_state') or {}).get('name')
    return score >= 75 and stock.get('trend') == 'Up' and state not in {'Defensive','Recovery'}

# Defensive guard: stale caches or brokerage imports must never allow a cash
# equivalent into the tradable stock collection.
stocks=[st for st in stocks if not is_cash_equivalent(st.get('symbol'), st.get('company'))]

for st in stocks:
    if st.get('symbol') in SPECIAL_SITUATION_SYMBOLS:
        st['group']='Special Situations'; st['role']='Special'; st['status']='Hold'; st['target']='5–10%'
        if st.get('symbol') == 'MP':
            st['own_reason']='Special Situation — Rare Earths / Magnets / AI Infrastructure test'
            st['score_reason']='Special situation; OPS remains informational and does not authorize normal accumulation.'
    st['has_active_position']=has_active_position(st)
    st['lifecycle_state']=resolve_lifecycle_state(st)
    st['position_status']='Active' if st['has_active_position'] else (('Confirmed Candidate' if st.get('qualified_candidate') else 'Emerging Candidate') if st['lifecycle_state']=='active_candidate' else ('Recently Exited' if st['lifecycle_state']=='recently_exited' else 'Archived'))
    lifecycle.setdefault('symbols', {}).setdefault(st['symbol'], {})
    lifecycle['symbols'][st['symbol']].update({
        'state': st['lifecycle_state'],
        'quantity': round(float(st.get('quantity') or 0), 6),
        'market_value': round(float(st.get('value') or 0), 2),
        'last_position_file': pos_file
    })
    st['buy']=[]; st['sell']=[]
    st['position_state']=position_state(st) if st['has_active_position'] else ({'name':'New Opportunity','action':'Confirmed candidate with an active buy ladder.'} if st.get('qualified_candidate') else {'name':'Emerging Opportunity','action':'Automatically discovered; a preview buy ladder is prepared now and becomes active after the second qualifying trading session.'})
    # BR-027/072/073/079: buy and sell decisions are independent. Owned
    # positions with a strong confirmed signal may retain an accumulation ladder
    # while their sell/harvest ladder remains visible. Ownership alone must never
    # suppress a valid buy ladder.
    can_buy=(not st['has_active_position']) or owned_buy_eligible(st)
    st['buy_eligible']=bool(can_buy)
    b=buy_levels(st['symbol'], st['price']) if can_buy else []
    bud=budget_for(st['symbol'], st['has_active_position'], st.get('group',''), st.get('opportunity',0), st.get('weight',0))
    if b:
        splits=[.5,.3,.2] if len(b)==3 else [1]
        for i,(label,price,note) in enumerate(b):
            alloc=bud*(splits[i] if i<len(splits) else 1/len(b))
            sh=round_trade_shares(alloc/price) if price else 0
            ladder_active=st['has_active_position'] or st.get('qualified_candidate')
            ladder_status='Active' if ladder_active else 'Preview — pending confirmation'
            ladder_note=note if ladder_active else f"{note}; do not place until confirmation reaches 2/2"
            st['buy'].append({'level':i+1,'label':label,'price':price,'allocation':alloc,'shares':sh,'status':ladder_status,'note':ladder_note})
    for i,(label,price,sh,note) in enumerate(sell_levels(st['symbol'], st['price'], st['quantity'], st.get('avg_cost',0), st.get('value',0), st.get('opportunity',0), account_total, st.get('group',''))):
        proceeds=(price or 0)*(sh or 0)
        trim_pct=(float(sh or 0)/float(st.get('quantity') or 1))*100 if float(st.get('quantity') or 0)>0 else 0
        st['sell'].append({'level':i+1,'label':label,'price':price,'shares':sh,'trim_pct':trim_pct,'proceeds':proceeds,'note':note})
    target_weight=target_weight_for_score(st['symbol'], st.get('opportunity',0), st.get('group',''))
    st['target_weight_pct']=target_weight*100 if target_weight is not None else None
    st['excess_weight_pct']=max(0.0, float(st.get('weight') or 0)-st['target_weight_pct']) if st['target_weight_pct'] is not None else None
    apply_vacation_order_guidance(st)
    st['shadow_preservation_ladder']=build_shadow_preservation_ladder(st, shadow_capital_preservation)

# Ladder QA: marketable sell limits are invalid unless explicitly approved.
# AMZN uses a 1.5% minimum harvest distance; all other ordinary sell ladders
# must at minimum remain above the latest market price.
for st in stocks:
    if is_cash_equivalent(st.get('symbol'), st.get('company')):
        continue
    current=float(st.get('price') or 0)
    if current <= 0:
        continue
    for rung in st.get('sell',[]):
        sell_price=float(rung.get('price') or 0)
        if sell_price <= current:
            raise ValueError(f"Invalid sell ladder for {st['symbol']}: {sell_price} is not above current price {current}")
        avg_cost=float(st.get('avg_cost') or 0)
        if avg_cost > 0 and sell_price <= avg_cost:
            raise ValueError(f"Invalid sell ladder for {st['symbol']}: {sell_price} is not above average cost basis {avg_cost}")
    if st.get('symbol') == 'AMZN' and st.get('sell'):
        minimum=round(current*1.015,2)
        if float(st['sell'][0]['price']) < minimum:
            raise ValueError(f"Invalid AMZN first sell rung: {st['sell'][0]['price']} is below validated minimum {minimum}")

# Portfolio Classification Engine v1.0
# Ownership determines whether a position is actively managed; opportunity
# determines where non-owned securities sit in the research pipeline.
def classify_portfolio_role(stock):
    sym=stock.get('symbol')
    if sym in SPECIAL_SITUATION_SYMBOLS:
        return 'Special Situations', 'Special', 'Hold', '5–10%'
    if stock.get('has_active_position'):
        return stock.get('group'), stock.get('role'), stock.get('status'), stock.get('target')
    score=float(stock.get('opportunity') or 0)
    if score >= 60:
        return 'Growth Candidates', 'Growth Candidate', 'Candidate', '0–10%'
    return 'Watch List', 'Watch', 'Watch Only', '0%'

for st in stocks:
    st['group'], st['role'], st['status'], st['target'] = classify_portfolio_role(st)

group_meta={
 'Core Compounders': {'num':1,'color':'blue','target':'40–50%','desc':'Best-in-class leaders'},
 'Tactical Compounders': {'num':2,'color':'green','target':'20–40%','desc':'High-growth tactical leaders'},
 'Growth Engine': {'num':3,'color':'purple','target':'10–20%','desc':'Approved incubators'},
 'Special Situations': {'num':4,'color':'orange','target':'5–10%','desc':'Unique / event-driven'},
 'Growth Candidates': {'num':5,'color':'yellow','target':'0–10%','desc':'Automatic broad-market pipeline'},
}

save_lifecycle(lifecycle)
visible_stocks = [s for s in stocks if lifecycle_visible(s)]
active_holdings = [s['symbol'] for s in visible_stocks if s['lifecycle_state'] == 'owned']
approved_universe = [s['symbol'] for s in visible_stocks if s['lifecycle_state'] in {'owned','active_candidate'}]
watch_only = []
legacy_holdings = [sym for sym, meta in lifecycle.get('symbols',{}).items() if meta.get('state') in {'recently_exited','archived'}]

html_data=json.dumps({'stocks':visible_stocks,'active_holdings':active_holdings,'approved_universe':approved_universe,'watch_only':watch_only,'legacy_holdings':legacy_holdings,'position_lifecycle':lifecycle,'benchmark':QQQ_BENCHMARK,'shadow_market_regime':shadow_regime,'shadow_capital_preservation':shadow_capital_preservation,'metrics':{'account_total':account_total,'cash':cash,'pending':pending,'effective_cash':effective_cash,'deployable':deployable,'roi':roi,'personal_roi':personal_roi,'twr':twr,'net_gain':net_gain,'total_contributions':TOTAL_CONTRIBUTIONS,'new_contribution':NEW_CONTRIBUTION,'capital_ledger':capital_ledger,'today_pl':today_pl,'today_pl_pct':today_pl_pct,'roi_pacing':roi_pacing,'annual_roi_goal':100.0,'baseline':BASELINE,'version':VERSION,'ladder_for':LADDER_FOR,'data_as_of':DATA_AS_OF,'scan_status':('Partial / cached' if score_payload.get('benchmark_stale') or (score_payload.get('download_diagnostics') or {}).get('rate_limit_detected') else 'Fresh'),'scan_universe_count':score_payload.get('universe_count') or len(scores),'scan_eligible_count':score_payload.get('eligible_technical_count') or len(scores),'confirmed_candidate_count':len(confirmed_candidate_symbols),'emerging_candidate_count':len(candidate_symbols)-len(confirmed_candidate_symbols)},'groups':group_meta}, ensure_ascii=False)

css=r'''

:root{--bg:#07111d;--panel:#0c1726;--panel2:#101d2e;--line:#1e344d;--ink:#ecf5ff;--muted:#8ea4bc;--blue:#1e88ff;--green:#37d353;--red:#ff4d4d;--yellow:#ffbf2f;--purple:#b15cff;--orange:#ff9f1a;--gray:#8290a2}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 25% 0%,#10213a,#050b13 42%,#03070d);color:var(--ink);font-family:Inter,Segoe UI,Arial,sans-serif}.app{display:grid;grid-template-columns:300px 1fr;gap:18px;padding:14px;min-height:100vh}.sidebar{background:rgba(12,23,38,.92);border:1px solid var(--line);border-radius:14px;padding:12px;height:calc(100vh - 28px);position:sticky;top:14px;overflow:auto}.brand{font-size:25px;font-weight:900;display:flex;align-items:center;gap:8px;white-space:nowrap;min-width:0}.brand-name{white-space:nowrap;display:inline-block}.brand .icon{flex:0 0 auto}.brand .green{color:#4fe36b}.version{font-size:13px;border:1px solid #1e88ff;color:#5fb5ff;padding:3px 8px;border-radius:6px;margin-left:auto}.subtitle{color:var(--muted);font-size:13px;margin:4px 0 18px 36px;white-space:nowrap}.decision-mini{border:1px solid var(--line);border-radius:10px;padding:12px;margin-bottom:14px;background:#081320}.decision-mini h3{margin:0 0 8px;font-size:14px}.search{display:flex;gap:8px;margin:12px 0}.search input{width:100%;background:#07111d;border:1px solid var(--line);border-radius:8px;color:var(--ink);padding:10px}.group{border:1px solid var(--line);border-radius:11px;margin:10px 0;overflow:hidden}.group-head{padding:10px 12px;font-weight:900;display:flex;justify-content:space-between;align-items:center;background:#0b1625}.group-head small{display:block;color:var(--muted);font-weight:600;margin-top:3px}.g-blue{border-color:#165aa8}.g-blue .group-head{color:#5fb5ff}.g-green{border-color:#238b3b}.g-green .group-head{color:#65e879}.g-purple{border-color:#7f3fc2}.g-purple .group-head{color:#ce94ff}.g-orange{border-color:#b96900}.g-orange .group-head{color:#ffb84a}.g-yellow{border-color:#9a7610}.g-yellow .group-head{color:#ffd55c}.g-red{border-color:#a82424}.g-red .group-head{color:#ff6d6d}.g-gray{border-color:#586579}.g-gray .group-head{color:#b7c1cf}.stock-nav{display:grid;grid-template-columns:1fr auto auto;gap:7px;align-items:center;padding:9px 10px;border-top:1px solid rgba(255,255,255,.06);cursor:pointer}.stock-nav:hover,.stock-nav.active{background:#10243a}.stock-nav{position:relative}.candidate-tooltip{display:none;position:fixed;z-index:1000;width:330px;padding:12px 13px;border:1px solid #315579;border-radius:10px;background:#07111d;box-shadow:0 14px 34px rgba(0,0,0,.45);pointer-events:none}.stock-nav:hover .candidate-tooltip{display:block}.candidate-tooltip .tt-title{font-size:15px;font-weight:900;margin-bottom:3px}.candidate-tooltip .tt-sub{font-size:11px;color:var(--muted);margin-bottom:9px}.candidate-tooltip .tt-grid{display:grid;grid-template-columns:1fr auto;gap:5px 12px;font-size:12px}.candidate-tooltip .tt-grid span{color:var(--muted)}.candidate-tooltip .tt-why{margin-top:9px;padding-top:8px;border-top:1px solid var(--line);font-size:12px;line-height:1.35}.candidate-tooltip .tt-ladder{margin-top:9px;padding-top:8px;border-top:1px solid var(--line)}.candidate-tooltip .tt-ladder-title{font-size:11px;font-weight:900;color:var(--green);text-transform:uppercase;margin-bottom:5px}.candidate-tooltip .tt-ladder.sell-mini .tt-ladder-title{color:var(--red)}.candidate-tooltip .tt-ladder-row{display:grid;grid-template-columns:26px 1fr auto;gap:8px;align-items:center;padding:4px 0;font-size:12px}.candidate-tooltip .tt-ladder-row span:first-child{color:var(--muted)}.candidate-tooltip .tt-ladder-row b{font-size:13px}.candidate-tooltip .tt-ladder-row em{font-style:normal;color:var(--ink);white-space:nowrap}.candidate-tooltip .tt-ladder-empty{font-size:11px;color:var(--muted)}.duration-badge{display:inline-block;padding:2px 6px;border-radius:6px;font-size:10px;font-weight:900;border:1px solid var(--line);white-space:nowrap}.duration-badge.gtc{color:var(--green);border-color:#238b3b;background:rgba(35,139,59,.13)}.duration-badge.day{color:#5fb5ff;border-color:#165aa8;background:rgba(22,90,168,.13)}.duration-badge.review{color:var(--yellow);border-color:#9a7610;background:rgba(154,118,16,.13)}.duration-badge.wait{color:var(--muted)}.sym{font-weight:900}.sell-coverage{font-size:10px;color:var(--red);font-weight:800;margin-left:4px;white-space:nowrap}.company-small{color:var(--muted);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.pill{font-size:12px;background:#123a62;border:1px solid #265e91;border-radius:7px;padding:3px 7px}.trend{font-weight:900}.trend.up{color:var(--green)}.trend.lateral{color:var(--yellow)}.trend.down{color:var(--red)}.main{min-width:0}.kpis{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px;margin-bottom:14px}
.kpi.roi-mission{grid-column:span 2}
.kpi.decision-kpi{grid-column:span 1;cursor:pointer;padding:11px 14px;min-height:82px}
.kpi.decision-kpi .label{font-weight:900}
.kpi.decision-kpi .decision-symbol{font-size:20px;font-weight:900;margin-top:5px}
.kpi.decision-kpi .decision-score{float:right;font-size:16px;font-weight:900}
.kpi.decision-kpi.buy{border-color:#24903a}
.kpi.decision-kpi.manage{border-color:#b62626}
.kpi.decision-kpi.risk{border-color:#b47a00}.kpi{background:linear-gradient(180deg,#0d1929,#08111e);border:1px solid var(--line);border-radius:12px;padding:14px}.kpi .label{color:#b8c8dc;font-size:12px;text-transform:uppercase}.kpi .value{font-size:25px;font-weight:900;margin-top:8px}.positive{color:var(--green)}.negative{color:var(--red)}.progress{height:12px;background:#04101c;border-radius:999px;overflow:hidden;margin-top:12px}.bar{height:100%;background:linear-gradient(90deg,#39d353,#a8ff60);border-radius:999px}.decision{background:rgba(12,23,38,.9);border:1px solid var(--line);border-radius:13px;padding:14px;margin-bottom:14px}.decision-title{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}.decision-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.dec-card{border-radius:12px;border:1px solid var(--line);padding:16px;background:#091523}.dec-card.buy{border-color:#24903a;background:linear-gradient(135deg,rgba(18,95,34,.45),rgba(9,21,35,.9))}.dec-card.sell{border-color:#b62626;background:linear-gradient(135deg,rgba(114,26,35,.5),rgba(9,21,35,.9))}.dec-card.watch{border-color:#b47a00;background:linear-gradient(135deg,rgba(117,80,0,.45),rgba(9,21,35,.9))}.dec-card h3{margin:0 0 8px;text-transform:uppercase}.dec-symbol{font-size:28px;font-weight:900}.scorebig{float:right;font-size:24px;font-weight:900}.detail{background:rgba(12,23,38,.9);border:1px solid var(--line);border-radius:13px;padding:0;overflow:hidden}.stock-hero{display:grid;grid-template-columns:1.2fr 1.4fr auto;gap:16px;padding:20px;border-bottom:1px solid var(--line);align-items:center}.stock-title{font-size:32px;font-weight:900}.tags span{display:inline-block;margin-right:6px;margin-top:8px;padding:5px 9px;border-radius:6px;background:#0b3b71;color:#80c7ff;font-size:12px;font-weight:900}.metrics-row{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}.mini-metric{border-left:1px solid var(--line);padding-left:12px}.mini-metric small{color:var(--muted);display:block}.mini-metric b{font-size:20px}.actions button{background:#0a3768;color:white;border:1px solid #2362a2;border-radius:7px;padding:8px 10px;margin-left:6px}.tabs{display:flex;gap:26px;padding:0 20px;border-bottom:1px solid var(--line)}.tab{padding:14px 0;color:var(--muted);font-weight:800}.tab.active{color:#48a7ff;border-bottom:2px solid #48a7ff}.content{display:grid;grid-template-columns:1.35fr 1fr 300px;gap:12px;padding:14px}.ladder-stack{display:flex;flex-direction:column;gap:12px;min-width:0}.ladder{border:1px solid var(--line);border-radius:10px;background:#081320;overflow:hidden}.ladder h3{margin:0;padding:12px 14px;border-bottom:1px solid var(--line)}.ladder.buy h3{color:var(--green)}.ladder.sell h3{color:var(--red)}table{width:100%;border-collapse:collapse}th,td{padding:10px;border-bottom:1px solid rgba(255,255,255,.06);text-align:left;font-size:13px}th{color:var(--muted);font-size:11px;text-transform:uppercase}.levelbox{display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:7px;background:#164f26;color:#d7ffd9;font-weight:900}.sell .levelbox{background:#5a1d23;color:#ffd8d8}.price{font-size:20px;font-weight:900}.limit{font-size:11px;color:#69e76e}.sell .limit{color:#ff7777}.side-panel{display:flex;flex-direction:column;gap:12px}.box{background:#081320;border:1px solid var(--line);border-radius:10px;padding:14px}.box h3{margin:0 0 12px}.profile-row{display:grid;grid-template-columns:1fr 120px 42px;gap:8px;align-items:center;margin:9px 0}.meter{height:9px;background:#0d2238;border-radius:99px;overflow:hidden}.meter span{display:block;height:100%;background:var(--green)}.lower{display:grid;grid-template-columns:1fr 1fr 1.2fr 1fr;gap:12px;padding:0 14px 14px}.chart{height:130px;border-radius:9px;background:linear-gradient(180deg,rgba(57,211,83,.12),rgba(57,211,83,.02));border:1px solid rgba(57,211,83,.25);position:relative;overflow:hidden}.chart:after{content:'';position:absolute;left:15px;right:15px;bottom:22px;height:65px;background:linear-gradient(135deg,transparent 0 8%,rgba(57,211,83,.8) 9% 10%,transparent 11% 22%,rgba(57,211,83,.8) 23% 24%,transparent 25% 42%,rgba(57,211,83,.8) 43% 44%,transparent 45% 58%,rgba(57,211,83,.8) 59% 60%,transparent 61% 78%,rgba(57,211,83,.8) 79% 80%,transparent 81%)}.footer-grid{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px;margin-top:12px}.small-card{background:rgba(12,23,38,.9);border:1px solid var(--line);border-radius:11px;padding:12px;min-width:0}.small-card p{font-size:11px;line-height:1.25}.small-card h3{font-size:14px}.small-card .bench-big{font-size:26px;font-weight:900}.small-card .bench-line{display:flex;justify-content:space-between;gap:8px;font-size:12px;margin:6px 0}.small-card h3{margin:0 0 10px}.rank-row{display:grid;grid-template-columns:26px 1fr auto;gap:8px;margin:7px 0}.footer{color:var(--muted);font-size:12px;text-align:center;margin:14px}.hidden{display:none!important}.health-score{font-size:34px;font-weight:900;margin:4px 0}.health-bars{display:grid;gap:8px;margin-top:10px}.health-line{display:grid;grid-template-columns:120px 1fr 42px;gap:8px;align-items:center;font-size:12px}.health-meter{height:9px;background:#0d2238;border-radius:99px;overflow:hidden}.health-meter span{display:block;height:100%;background:linear-gradient(90deg,#39d353,#a8ff60)}.callout{margin-top:10px;padding:8px;border:1px solid var(--line);border-radius:8px;background:#081320}.callout b{display:block;margin-bottom:4px}.warning-text{color:var(--yellow)}.bench-range{width:100%;accent-color:#37d353;margin:6px 0}.bench-date-row{display:flex;justify-content:space-between;gap:6px;color:var(--muted);font-size:10px}.bench-note{font-size:10px;color:var(--muted);line-height:1.2;margin-top:3px}.bench-microgrid{display:grid;grid-template-columns:1fr 1fr;gap:4px 8px;margin-top:5px}.bench-micro{font-size:10px;color:var(--muted);min-width:0}.bench-micro b{display:block;color:var(--ink);font-size:11px;white-space:nowrap}.bench-micro b.positive{color:var(--green)}.bench-micro b.negative{color:var(--red)}.bench-sub{font-size:10px;color:var(--muted);margin-top:-6px;margin-bottom:3px}.bench-period{font-size:10px;color:var(--muted);display:flex;justify-content:space-between;margin:3px 0}.bench-alpha-label{font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.02em}@media(max-width:1200px){.app{grid-template-columns:1fr}.sidebar{position:relative;height:auto}.kpis,.decision-grid,.content,.lower,.footer-grid{grid-template-columns:1fr}.kpi.roi-mission,.kpi.decision-kpi{grid-column:span 1!important}.stock-hero{grid-template-columns:1fr}.metrics-row{grid-template-columns:repeat(2,1fr)}}

'''

script=r'''
const DATA = __DATA__;
const fmtMoney = v => '$' + Number(v||0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});
const fmtPct = v => Number(v||0).toFixed(2)+'%';
const fmtTradeSh = v => Number(v||0).toFixed(1).replace(/\.0$/,'');
const fmtOwnedSh = v => Number(v||0).toFixed(3).replace(/\.0+$/,'').replace(/(\.\d*?)0+$/,'$1');
const fmtOps = v => { const n=Number(v||0); return Math.abs(n-Math.round(n))<0.05 ? String(Math.round(n)) : n.toFixed(1); };
function trendClass(t){return (t||'').toLowerCase()==='up'?'up':((t||'').toLowerCase()==='down'?'down':'lateral')}
function trendIcon(t){return (t||'').toLowerCase()==='up'?'↑':((t||'').toLowerCase()==='down'?'↓':'→')}
function ladderDisplayDate(){return DATA.metrics.ladder_for;}
function formatEasternDate(){return ladderDisplayDate();}
function nextLadderDate(){return ladderDisplayDate();}

function kpi(){
 const m=DATA.metrics;
 const mr=DATA.shadow_market_regime||{};
 const mrScore=Number(mr.score), mrHas=Number.isFinite(mrScore), mrRegime=mr.regime||'Pending', mrPct=Number(mr.shadow_capital_pct||100);
 const mrClass=mrHas?(mrScore>=55?'positive':(mrScore<40?'negative':'warning-text')):'';
 const cp=DATA.shadow_capital_preservation||{};
 const cpScore=Number(cp.score), cpHas=Number.isFinite(cpScore), cpRegime=cp.regime||'Pending', cpPct=Number(cp.shadow_capital_pct||100);
 const cpClass=cpHas?(cpScore<25?'positive':(cpScore>=65?'negative':'warning-text')):'';

 // Decision Center is now a compact attention/navigation layer only.
 // Recommendation State + ladders remain the authoritative trading instructions.
 const candidates=DATA.stocks.filter(s=>s.lifecycle_state!=='archived');
 const buy=[...candidates].filter(s=>s.buy?.length).sort((a,b)=>Number(b.final_ops??b.opportunity??0)-Number(a.final_ops??a.opportunity??0))[0] || candidates[0];
 const manage=[...candidates].filter(s=>s.has_active_position && s.sell?.length).sort((a,b)=>(b.weight||0)-(a.weight||0))[0] || candidates.find(s=>s.has_active_position) || candidates[0];
 const risk=[...candidates].filter(s=>s.has_active_position && s.trend!=='Up').sort((a,b)=>Number(a.final_ops??a.opportunity??0)-Number(b.final_ops??b.opportunity??0))[0] || candidates.find(s=>s.has_active_position) || candidates[0];
 PRIMARY_DECISION_SYMBOL=buy?.symbol || candidates[0]?.symbol || null;
 const compact=(kind,label,stock)=>stock?`<div class="kpi decision-kpi ${kind}" onclick="selectStock('${stock.symbol}')" title="Attention/navigation only. Open the stock to view the authoritative Recommendation State and ladder."><div class="label">${label}<span class="decision-score">${fmtOps(stock.final_ops??stock.opportunity??0)}</span></div><div class="decision-symbol">${stock.symbol}</div><small>${stock.position_state?.name||stock.trend||''} · View ladder →</small></div>`:'';

 document.getElementById('kpis').innerHTML=`
 <div class="kpi"><div class="label">Account Total</div><div class="value">${fmtMoney(m.account_total)}</div><small>Market value</small></div>
 <div class="kpi"><div class="label">Effective Cash</div><div class="value">${fmtMoney(m.effective_cash)}</div><small>Raw cash + pending</small></div>
 <div class="kpi"><div class="label">Buying Power</div><div class="value">${fmtMoney(m.deployable)}</div><small>After 15% reserve</small></div>
 <div class="kpi" title="Shadow observer only. This score does not affect OPS, recommendations, buy/sell ladders, or live capital allocation."><div class="label">Market Regime · Shadow</div><div class="value ${mrClass}">${mrHas?mrScore.toFixed(1):'—'}</div><small><b>${mrRegime}</b> · Hypothetical buy capital ${mrPct}%</small></div>
 <div class="kpi" title="Phase 1 recession/crisis observer only. Four pillars: market deterioration, economic deterioration, financial stress, and breadth/leadership stress. Does not affect live ladders."><div class="label">Capital Preservation · Shadow</div><div class="value ${cpClass}">${cpHas?cpScore.toFixed(1):'—'}</div><small><b>${cpRegime}</b> · Hypothetical buy capital ${cpPct}%</small></div>
 <div class="kpi"><div class="label">Strategy Return (TWR)</div><div class="value ${m.twr>=0?'positive':'negative'}">${m.twr>=0?'+':''}${fmtPct(m.twr)}</div><small>Personal ROI ${m.personal_roi>=0?'+':''}${fmtPct(m.personal_roi)} · Net gain ${m.net_gain>=0?'+':''}${fmtMoney(m.net_gain)}</small></div>
 <div class="kpi"><div class="label">Today's P/L</div><div class="value ${m.today_pl>=0?'positive':'negative'}">${m.today_pl>=0?'+':''}${fmtMoney(m.today_pl)}</div><small>${m.today_pl>=0?'+':''}${fmtPct(m.today_pl_pct)}</small></div>
 <div class="kpi roi-mission"><div class="label">100% ROI Mission Pace</div><div class="value ${m.roi_pacing.status==='Ahead'?'positive':'negative'}">${m.roi_pacing.status}</div><small>Current ${fmtPct(m.roi)} · Required ${fmtPct(m.roi_pacing.required_to_date_pct)}</small><div class="progress"><div class="bar" style="width:${Math.min(100,Math.max(0,m.roi_pacing.pace_ratio_pct))}%"></div></div></div>
 ${compact('buy','BUY',buy)}
 ${compact('manage','MANAGE',manage)}
 ${compact('risk','RISK',risk)}`;
}
function sidebar(){const groups=DATA.groups; const by={}; const trendRank={Up:3,Lateral:2,Down:1}; DATA.stocks.forEach(s=>{(by[s.group]??=[]).push(s)}); Object.entries(by).forEach(([group,arr])=>arr.sort((a,b)=>{
  const aOps=Number(a.final_ops??a.opportunity??0), bOps=Number(b.final_ops??b.opportunity??0);
  if(group==='Growth Candidates'){
    // v3.60.22: OPS remains the primary signal. Candidates within the same
    // 5-point OPS band are ranked by expected upside, then exact OPS.
    const aBand=Math.floor(aOps/5), bBand=Math.floor(bOps/5);
    return bBand-aBand || Number(b.expected_upside_pct||0)-Number(a.expected_upside_pct||0) || bOps-aOps || (trendRank[b.trend]||0)-(trendRank[a.trend]||0) || (b.leadership||0)-(a.leadership||0) || (a.rank||99)-(b.rank||99);
  }
  return bOps-aOps || (trendRank[b.trend]||0)-(trendRank[a.trend]||0) || (b.leadership||0)-(a.leadership||0) || (a.rank||99)-(b.rank||99);
})); let html='<div class=\"brand\"><span class=\"icon\">📈</span><span class=\"brand-name\">LadderIQ</span><span class=\"version\">'+DATA.metrics.version+'</span></div><div class="subtitle">Portfolio Command Center</div><h3>Portfolio Hierarchy</h3><div style="color:var(--muted);font-size:11px;margin-top:-4px;margin-bottom:8px">Sidebar number = Opportunity Score, not business quality.</div><div class="search"><input placeholder="Search symbols..." oninput="filterStocks(this.value)"></div>';
 Object.keys(groups).forEach(g=>{const meta=groups[g]; const arr=by[g]||[]; html+=`<div class="group g-${meta.color}"><div class="group-head"><div>${meta.num} ${g}<small>Target: ${meta.target} · ${arr.length} ${g==='Growth Candidates' ? (arr.length===1?'Candidate':'Candidates') : 'Holdings'}</small></div><div>⌄</div></div>`; arr.forEach(s=>{const isGrowth=g==='Growth Candidates'; const conf=(s.confirmation_days||0)+'/2 days'; const upside=Number(s.expected_upside_pct||0); const why=s.score_reason||s.subtitle||'Automatically discovered broad-market opportunity.'; const buyLadder=(s.buy||[]).slice(0,3); const sellLadder=(s.sell||[]).slice(0,3); const totalSellShares=(s.sell||[]).reduce((sum,x)=>sum+Number(x.shares||0),0); const sellCoverage=(Number(s.quantity||0)>0&&totalSellShares>0)?Math.min(100,Math.round(totalSellShares/Number(s.quantity)*100)):0; const sellCoverageHtml=sellCoverage?`<span class="sell-coverage">(Sell: ${sellCoverage}%)</span>`:''; const buyHtml=buyLadder.length?`<div class="tt-ladder"><div class="tt-ladder-title">Buy Ladder</div>${buyLadder.map(x=>`<div class="tt-ladder-row"><span>L${x.level}</span><b>${fmtMoney(x.price)}</b><em>${fmtTradeSh(x.shares)} sh · ${x.duration||''}</em></div>`).join('')}</div>`:''; const sellHtml=sellLadder.length?`<div class="tt-ladder sell-mini"><div class="tt-ladder-title">Sell Ladder</div>${sellLadder.map(x=>`<div class="tt-ladder-row"><span>L${x.level}</span><b>${fmtMoney(x.price)}</b><em>${fmtTradeSh(x.shares)} sh · ${x.duration||''}</em></div>`).join('')}</div>`:''; const noLadder=(!buyLadder.length&&!sellLadder.length)?`<div class="tt-ladder"><div class="tt-ladder-title">Ladder</div><div class="tt-ladder-empty">No active ladder.</div></div>`:''; const state=s.position_state?.name||(isGrowth?'Growth Candidate':'Manage'); const tip=`<div class="candidate-tooltip"><div class="tt-title">${s.symbol} · ${s.sector||'Unclassified'}</div><div class="tt-sub">${state} · ${s.industry||s.company}</div><div class="tt-grid"><span>News-Refined OPS</span><b>${fmtOps(s.final_ops??s.opportunity??s.leadership)}</b>${Number(s.news_adjustment||0)!==0?`<span>News Impact</span><b class="${Number(s.news_adjustment)>0?'positive':'negative'}">${Number(s.news_adjustment)>0?'+':''}${Number(s.news_adjustment).toFixed(1)}</b>`:''}<span>Business Quality</span><b>${Math.round(s.business_quality??0)}</b>${isGrowth?`<span>Confirmation</span><b>${conf}</b><span>Expected Upside</span><b>${upside?fmtPct(upside):'—'}</b>`:`<span>Portfolio Weight</span><b>${fmtPct(s.weight||0)}</b><span>Shares Owned</span><b>${fmtOwnedSh(s.quantity||0)}</b>`}</div>${buyHtml}${sellHtml}${noLadder}<div class="tt-why"><b>Why now:</b> ${why}</div></div>`; html+=`<div class="stock-nav ${isGrowth?'growth-candidate':''}" data-symbol="${s.symbol}" onclick="selectStock('${s.symbol}')" onmousemove="positionCandidateTooltip(event,this)"><div><div class="sym">${s.symbol}${sellCoverageHtml}</div><div class="company-small">${s.company}</div></div><span class="pill" title="Opportunity Score: where the next dollar should go today">${fmtOps(s.final_ops ?? s.opportunity ?? s.leadership)}<small style="font-size:8px;margin-left:2px">OPS</small></span><span class="trend ${trendClass(s.trend)}">${s.trend}</span>${tip}</div>`}); html+='</div>'});
 html+=`<div class="box"><small>Data as of: ${DATA.metrics.data_as_of}</small></div>`; document.getElementById('sidebar').innerHTML=html;}
let PRIMARY_DECISION_SYMBOL=null;
function decision(){
 const el=document.getElementById('decision');
 if(el){el.innerHTML='';el.classList.add('hidden');}
}
function durationBadge(x){const d=String(x.duration||'').toUpperCase();const cls=d==='GTC'?'gtc':d==='DAY'?'day':d==='REVIEW'?'review':'wait';return `<span class="duration-badge ${cls}" title="${x.duration_reason||''}">${d||'—'}</span>`;}
function ladderRows(levels,type,hasPosition=true){if(!levels.length){const msg=(type==='sell'&&!hasPosition)?'<b>Position Closed</b><br><span style="color:var(--muted)">No shares are currently owned. No sell ladder is required.</span>':'No ladder for this side.';return `<tr><td colspan="7">${msg}</td></tr>`;}return levels.map(x=>`<tr><td><span class="levelbox">${x.level}</span></td><td><div class="price">${fmtMoney(x.price)}</div><div class="limit">Limit ${type==='buy'?'Buy':'Sell'}</div></td><td>${type==='buy'?fmtMoney(x.allocation):fmtPct(x.trim_pct||0)}</td><td>${fmtTradeSh(x.shares)}</td><td>${type==='buy'?(x.status||'Waiting'):fmtMoney(x.proceeds)}</td><td>${durationBadge(x)}</td><td>${x.note||''}</td></tr>`).join('')}
function positionCandidateTooltip(event,row){const tip=row.querySelector('.candidate-tooltip');if(!tip)return;const pad=14,width=300,height=tip.offsetHeight||190;let left=event.clientX+16,top=event.clientY+12;if(left+width+pad>window.innerWidth)left=event.clientX-width-16;if(top+height+pad>window.innerHeight)top=window.innerHeight-height-pad;tip.style.left=Math.max(pad,left)+'px';tip.style.top=Math.max(pad,top)+'px';}
function preservationShadowHtml(s){
 const cp=DATA.shadow_capital_preservation||{}; const p=s.shadow_preservation_ladder||{};
 const pillars=cp.pillars||{}; const score=Number(cp.score);
 const hdr=`<div class="box"><h3>Capital Preservation · Shadow</h3><div style="font-size:24px;font-weight:900">${Number.isFinite(score)?score.toFixed(1):'—'} <small>/100 · ${cp.regime||'Pending'}</small></div><p>${cp.summary||'Phase 1 observer; no live ladder impact.'}</p><div class="profile-row"><span>Market deterioration</span><b>${Number(pillars.market_deterioration||0).toFixed(1)}</b></div><div class="profile-row"><span>Economic deterioration</span><b>${Number(pillars.economic_deterioration||0).toFixed(1)}</b></div><div class="profile-row"><span>Financial stress</span><b>${Number(pillars.financial_stress||0).toFixed(1)}</b></div><div class="profile-row"><span>Leadership stress</span><b>${Number(pillars.leadership_stress||0).toFixed(1)}</b></div>`;
 if(!p.active||!(p.levels||[]).length) return hdr+`<div class="callout"><b>Phase 1 policy</b><span>${p.reason||'No preservation override active.'} Live ladders remain unchanged.</span></div></div>`;
 const rows=p.levels.map(x=>`<tr><td><span class="levelbox">${x.level}</span></td><td><div class="price">${fmtMoney(x.price)}</div></td><td>${fmtPct(x.trim_pct||0)}</td><td>${fmtTradeSh(x.shares)}</td><td>${fmtMoney(x.proceeds)}</td><td class="${x.below_cost?'negative':''}">${x.below_cost?'BELOW BASIS':'Above basis'}</td><td>${x.note||''}</td></tr>`).join('');
 return hdr+`<div class="callout"><b>SHADOW ONLY — hypothetical Preservation ladder</b><span>This table is observational and must not be placed as live orders during Phase 1.</span></div><table><thead><tr><th>Level</th><th>Price</th><th>Trim</th><th>Shares</th><th>Proceeds</th><th>Basis</th><th>Why</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
function portfolioWeakness(){
 const holdings=(DATA.stocks||[]).filter(x=>Number(x.quantity||0)>0 && Number(x.value||0)>0);
 if(!holdings.length) return 'No active equity holdings available for concentration analysis.';
 const largest=holdings.reduce((a,b)=>Number(b.weight||0)>Number(a.weight||0)?b:a, holdings[0]);
 const w=Number(largest.weight||0);
 // Only call out single-stock concentration when the current imported position
 // is genuinely large. This replaces the legacy hard-coded NVDA warning.
 if(w>=25) return `${largest.symbol} is the largest concentration at ${fmtPct(w)} of the portfolio; monitor position sizing.`;
 return `No material single-stock concentration detected. Largest position: ${largest.symbol} at ${fmtPct(w)}.`;
}
function selectStock(sym){const s=DATA.stocks.find(x=>x.symbol===sym)||DATA.stocks[0]; document.querySelectorAll('.stock-nav').forEach(el=>el.classList.toggle('active',el.dataset.symbol===sym)); const pl=s.total_pl||0; document.getElementById('detail').innerHTML=`
 <div class="stock-hero"><div><div class="stock-title">${s.symbol}</div><div style="color:var(--muted)">${s.company}</div><div class="tags"><span>${s.role}</span><span>${s.group}</span></div></div><div class="metrics-row"><div class="mini-metric"><small>Opportunity</small><b>${fmtOps(s.final_ops ?? s.opportunity ?? s.leadership)}</b></div><div class="mini-metric"><small>Trend</small><b class="trend ${trendClass(s.trend)}">${trendIcon(s.trend)} ${s.trend}</b></div><div class="mini-metric"><small>Business Quality</small><b>${Math.round(s.business_quality ?? s.leadership)}</b></div><div class="mini-metric"><small>% Portfolio</small><b>${fmtPct(s.weight)}</b></div><div class="mini-metric"><small>Market Value</small><b>${fmtMoney(s.value)}</b></div></div><div class="actions"><button>Add Note</button><button>View Chart</button><button>Set Alert</button><div style="margin-top:12px"><small>Unrealized P/L</small><br><b class="${pl>=0?'positive':'negative'}">${pl>=0?'+':''}${fmtMoney(pl)}</b></div></div></div>
 <div class="tabs"><div class="tab active">Overview</div><div class="tab">Ladders</div><div class="tab">Analysis</div><div class="tab">Notes</div><div class="tab">Performance</div></div>
 <div class="content"><div class="ladder-stack">${s.buy?.length?`<div class="ladder buy"><h3>Buy Ladder · ${s.has_active_position?'Accumulate on Weakness':(s.qualified_candidate?'Confirmed':'Pending '+(s.confirmation_days||0)+'/2 Days')} <span style="float:right;color:var(--muted);font-size:13px">Budget: ${fmtMoney(s.buy.reduce((a,b)=>a+b.allocation,0))}</span></h3><table><thead><tr><th>Level</th><th>Price</th><th>Allocation</th><th>Shares</th><th>Status</th><th>Duration</th><th>Notes</th></tr></thead><tbody>${ladderRows(s.buy,'buy',false)}</tbody></table></div>`:''}${s.sell?.length?`<div class="ladder sell"><h3>Sell Ladder · ${s.position_state?.name||'Manage'} <span style="float:right;color:var(--muted);font-size:13px">Target: ${fmtMoney(s.sell.reduce((a,b)=>a+b.proceeds,0))}</span></h3><table><thead><tr><th>Level</th><th>Price</th><th>Trim</th><th>Shares</th><th>Proceeds</th><th>Duration</th><th>Notes</th></tr></thead><tbody>${ladderRows(s.sell,'sell',true)}</tbody></table></div>`:''}${(!s.buy?.length&&!s.sell?.length)?`<div class="box"><h3>No Active Ladder</h3><p>Current signal does not authorize a buy or sell ladder.</p></div>`:''}</div><div class="box"><h3>Recommendation State</h3><div style="font-size:24px;font-weight:900">${s.position_state?.name||'New Opportunity'}</div><p>${s.position_state?.action||''}</p><div>Base OPS <b style="float:right">${fmtOps(s.base_ops??s.raw_opportunity??s.opportunity)}</b></div><div>Confirmed OPS <b style="float:right">${fmtOps(s.confirmed_ops??s.opportunity)}</b></div><div>News Impact <b class="${Number(s.news_adjustment||0)>=0?'positive':'negative'}" style="float:right">${Number(s.news_adjustment||0)>0?'+':''}${Number(s.news_adjustment||0).toFixed(1)}</b></div><div>News-Refined OPS <b style="float:right">${fmtOps(s.final_ops??s.opportunity)}</b></div><div>Confirmation <b style="float:right">${s.confirmation_days||0}/2 days</b></div><div class="callout"><b>News Refinement</b><span>${s.news_reason || 'No material recent company-news event detected.'}</span></div><div class="callout"><b>Vacation Order Guide</b><span>L1 buys: DAY · L2/L3 buys: GTC · Sell ladders: GTC. Any rung marked REVIEW or WAIT overrides the default.</span></div></div><div class="side-panel"><div class="box"><h3>Score Breakdown</h3><div style="color:var(--muted);font-size:12px;margin-bottom:10px">Opportunity score is tactical. Business quality is long-term.</div>${['Relative Strength','Momentum','Price Structure','Capital Priority','Opportunity Score'].map((n,i)=>`<div class="profile-row"><span>${n}</span><div class="meter"><span style="width:${Math.max(10,Math.min(100,s.leadership-(i*2)))}%"></span></div><b>${Math.max(0,Math.round(s.leadership-(i*2)))}</b></div>`).join('')}</div><div class="box"><h3>Key Levels</h3><div>Current: <b style="float:right">${fmtMoney(s.price)}</b></div><div>Avg Cost: <b style="float:right">${fmtMoney(s.avg_cost)}</b></div><div>Shares: <b style="float:right">${fmtOwnedSh(s.quantity)}</b></div><div>Weight: <b style="float:right">${fmtPct(s.weight)}</b></div><div>Reason Owned: <b style="float:right">${s.own_reason || 'LadderIQ Selected'}</b></div><div class="callout"><b>Score Interpretation</b><span>${s.score_reason || 'Opportunity score controls today’s capital allocation.'}</span></div></div></div></div>${preservationShadowHtml(s)}
 <div class="lower"><div class="box"><h3>Technical Snapshot</h3><div>Price (AH) <b style="float:right">${fmtMoney(s.price)}</b></div><div>Trend <b class="trend ${trendClass(s.trend)}" style="float:right">${s.trend}</b></div><div>Opportunity <b style="float:right">${fmtOps(s.final_ops ?? s.opportunity ?? s.leadership)}</b></div><div>Business Quality <b style="float:right">${Math.round(s.business_quality ?? s.leadership)}</b></div></div><div class="box"><h3>Portfolio Health</h3><div class="health-score positive">91<small>/100</small></div><div class="positive">Excellent</div><div class="health-bars"><div class="health-line"><span>Opportunity</span><div class="health-meter"><span style="width:95%"></span></div><b>95</b></div><div class="health-line"><span>Diversification</span><div class="health-meter"><span style="width:84%"></span></div><b>84</b></div><div class="health-line"><span>Risk Mgmt</span><div class="health-meter"><span style="width:92%"></span></div><b>92</b></div><div class="health-line"><span>Cash Efficiency</span><div class="health-meter"><span style="width:78%"></span></div><b>78</b></div><div class="health-line"><span>Momentum</span><div class="health-meter"><span style="width:97%"></span></div><b>97</b></div></div><div class="callout"><b>Concentration Check</b><span class="warning-text">${portfolioWeakness()}</span></div></div><div class="box"><h3>Capital Allocation Engine</h3><div>Deployable cash: <b>${fmtMoney(DATA.metrics.deployable)}</b></div><div class="progress"><div class="bar" style="width:86%"></div></div><small>Cash efficiency: Good</small></div><div class="box"><h3>Allocation & Risk</h3><div style="font-size:34px;font-weight:900">${fmtPct(s.weight)}</div><div>Risk Status: <b class="positive">${s.weight>40?'Watch':'Good'}</b></div></div></div>`;}
function renderBenchmarkCard(){
 const b=DATA.benchmark || {};
 const series=(b.replay_series && b.replay_series.length)?b.replay_series:(b.series || []).map(x=>({date:x.date, qqq_price:x.price, qqq_roi:((Number(x.price)/Number(b.start_price))-1)*100, portfolio_roi:Number(DATA.metrics.roi||0)}));
 const maxIdx=Math.max(0,series.length-1);
 const defaultIdx=maxIdx;
 const end=series[defaultIdx] || {date:b.end_date, qqq_roi:b.return_pct, portfolio_roi:DATA.metrics.roi, alpha:b.alpha_pct};
 const port=Number(end.portfolio_roi ?? DATA.metrics.roi ?? 0);
 const qret=Number(end.qqq_roi ?? b.return_pct ?? 0);
 const bh=Number(end.buy_hold_roi ?? 0);
 const ladder=Number(end.ladder_alpha ?? (port-bh));
 const alpha=Number(end.alpha ?? (port-qret));
 const qqqValue=Number(end.qqq_value ?? (Number(DATA.metrics.baseline||0)*(1+qret/100)));
 const alphaDollars=Number(end.alpha_dollars ?? (Number(DATA.metrics.baseline||0)*(alpha/100)));
 const ladderValue=Number(end.ladder_value_added ?? 0);
 return `<div class="small-card"><h3>Benchmark vs QQQ</h3><div class="bench-alpha-label">Alpha vs QQQ</div><div id="benchAlpha" class="bench-big ${alpha>=0?'positive':'negative'}">${alpha>=0?'+':''}${fmtPct(alpha)}</div><div class="bench-line"><span>Portfolio TWR</span><b id="benchPortfolio">${port>=0?'+':''}${fmtPct(port)}</b></div><div class="bench-line"><span>QQQ ROI</span><b id="benchQQQ">${qret>=0?'+':''}${fmtPct(qret)}</b></div><div class="bench-microgrid"><div class="bench-micro">Buy & Hold<b id="benchBuyHold">${bh>=0?'+':''}${fmtPct(bh)}</b></div><div class="bench-micro">LadderIQ Value<b id="benchLadderValue" class="${ladderValue>=0?'positive':'negative'}">${ladderValue>=0?'+':''}${fmtMoney(ladderValue)}</b></div><div class="bench-micro">Ladder Alpha<b id="benchLadderAlpha" class="${ladder>=0?'positive':'negative'}">${ladder>=0?'+':''}${fmtPct(ladder)}</b></div><div class="bench-micro">Personal ROI<b id="benchPersonalROI">${Number(end.personal_roi ?? DATA.metrics.personal_roi ?? 0)>=0?'+':''}${fmtPct(Number(end.personal_roi ?? DATA.metrics.personal_roi ?? 0))}</b></div></div><div class="bench-period"><span>Period</span><b><span>${b.start_date||''}</span> → <span id="benchEndDate">${end.date||''}</span></b></div><input id="benchSlider" class="bench-range" type="range" min="0" max="${maxIdx}" value="${defaultIdx}" oninput="updateBenchmark(this.value)"><div class="bench-note">Start locked at 2026-04-07. Drag end date. Portfolio, QQQ, Buy & Hold, and LadderIQ Value update together.</div></div>`;
}
function updateBenchmark(idx){
 const b=DATA.benchmark || {}; const series=(b.replay_series && b.replay_series.length)?b.replay_series:(b.series || []);
 const item=series[Number(idx)] || series[series.length-1] || {};
 const port=Number(item.portfolio_roi ?? DATA.metrics.roi ?? 0);
 const qret=Number(item.qqq_roi ?? (((Number(item.price||item.qqq_price)/Number(b.start_price))-1)*100) ?? 0);
 const bh=Number(item.buy_hold_roi ?? 0);
 const ladder=Number(item.ladder_alpha ?? (port-bh));
 const alpha=Number(item.alpha ?? (port-qret));
 const ladderValue=Number(item.ladder_value_added ?? 0);
 const personal=Number(item.personal_roi ?? DATA.metrics.personal_roi ?? port);
 const alphaDollars=Number(item.alpha_dollars ?? (Number(DATA.metrics.baseline||0)*(alpha/100)));
 const qqqValue=Number(item.qqq_value ?? (Number(DATA.metrics.baseline||0)*(1+qret/100)));
 const setText=(id,txt)=>{const el=document.getElementById(id); if(el)el.textContent=txt;};
 const setClass=(id,base,val)=>{const el=document.getElementById(id); if(el)el.className=(base?base+' ':'')+(val>=0?'positive':'negative');};
 setText('benchAlpha',(alpha>=0?'+':'')+fmtPct(alpha)); setClass('benchAlpha','bench-big',alpha);
 setText('benchPortfolio',(port>=0?'+':'')+fmtPct(port));
 setText('benchQQQ',(qret>=0?'+':'')+fmtPct(qret));
 setText('benchBuyHold',(bh>=0?'+':'')+fmtPct(bh));
 setText('benchLadderAlpha',(ladder>=0?'+':'')+fmtPct(ladder)); setClass('benchLadderAlpha','',ladder);
 setText('benchLadderValue',(ladderValue>=0?'+':'')+fmtMoney(ladderValue)); setClass('benchLadderValue','',ladderValue);
 setText('benchPersonalROI',(personal>=0?'+':'')+fmtPct(personal));
 setText('benchEndDate',item.date || '');
 setText('benchAlphaDollars',(alphaDollars>=0?'+':'')+fmtMoney(alphaDollars)); setClass('benchAlphaDollars','',alpha);
 setText('benchQQQValue',fmtMoney(qqqValue));
 setText('benchStatus',alpha>=0?'Beating':'Lagging'); setClass('benchStatus','',alpha);
}
function footer(){
 const opp=['PANW','ANET','CRWD','TSM','ASML'].filter(x=>DATA.stocks.find(s=>s.symbol===x));
 const strategic=['NVDA','TSM','ASML','PANW'].filter(x=>DATA.stocks.find(s=>s.symbol===x));
 const emerging=['DELL','SNOW','VRT','ARM','GOOGL'];
 document.getElementById('footergrid').innerHTML=`<div class="small-card"><h3>Portfolio Health</h3><div style="font-size:30px;font-weight:900">94<small>/100</small></div><div class="positive">Excellent</div><p style="color:var(--muted)">Opportunity score drives new capital. Business quality stays separate.</p></div>${renderBenchmarkCard()}<div class="small-card"><h3>Opportunity Ranking</h3>${opp.map((r,i)=>{const st=DATA.stocks.find(s=>s.symbol===r); return `<div class="rank-row"><b>${i+1}</b><span>${r}</span><span class="positive">${fmtOps(st?.final_ops ?? st?.opportunity ?? st?.leadership ?? 0)}</span></div>`}).join('')}</div><div class="small-card"><h3>Strategic Leaders</h3>${strategic.map((r,i)=>{const st=DATA.stocks.find(s=>s.symbol===r); return `<div class="rank-row"><b>${i+1}</b><span>${r}</span><span>${Math.round(st?.business_quality ?? 0)}</span></div>`}).join('')}<p style="color:var(--muted)">Quality names; not always current buys.</p></div><div class="small-card"><h3>Watch / Emerging</h3>${emerging.map((r,i)=>`<div class="rank-row"><b>${i+1}</b><span>${r}</span><span>${i<2?'Attack':'Hold'}</span></div>`).join('')}</div>`;}
function filterStocks(q){q=(q||'').toUpperCase(); document.querySelectorAll('.stock-nav').forEach(el=>{el.style.display=el.dataset.symbol.includes(q)?'grid':'none'})}
kpi(); sidebar(); decision(); footer(); selectStock(PRIMARY_DECISION_SYMBOL || DATA.stocks[0]?.symbol); document.getElementById('nextLadderFooter').textContent=nextLadderDate();

'''.replace('__DATA__', html_data)

html=f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>LadderIQ {VERSION} Portfolio Command Center</title><style>{css}</style></head><body><div class="app"><aside id="sidebar" class="sidebar"></aside><main class="main"><section id="kpis" class="kpis"></section><section id="decision" class="decision"></section><section id="detail" class="detail"></section><section id="footergrid" class="footer-grid"></section><div class="footer">LadderIQ | {VERSION} | Data as of {DATA_AS_OF}</div></main></div><script>{script}</script></body></html>'''

# reports/latestladder.html is the authoritative generated report.
REPORTS_DIR = ROOT / 'reports'
ARCHIVE_DIR = REPORTS_DIR / 'archive'
REPORTS_DIR.mkdir(parents=True, exist_ok=True)
ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
AUTHORITATIVE_REPORT = REPORTS_DIR / 'latestladder.html'
AUTHORITATIVE_REPORT.write_text(html, encoding='utf-8')

# Preserve a dated snapshot when the build has a valid data date.
archive_name = f"{DATA_AS_OF[:10]}.html" if re.match(r'\d{4}-\d{2}-\d{2}', DATA_AS_OF) else None
if archive_name:
    (ARCHIVE_DIR / archive_name).write_text(html, encoding='utf-8')

# Transitional compatibility copies for old shortcuts and integrations.
(ROOT / 'latestladder.html').write_text(html, encoding='utf-8')
(ROOT / 'index.html').write_text(html, encoding='utf-8')
readme=fr'''# LadderIQ {VERSION} — Tomorrow Ladder

Updated with the latest Fidelity files detected in the project folder.

## Correct PowerShell Workflow

```powershell
cd "C:\Users\mcdph\OneDrive\03 - LadderIQ Platform\04 - Development"
python .\import_fidelity_csv.py
python .\import_positions.py
python .\leadership_scanner.py
python .\build_ladder.py
start .\reports\latestladder.html
```

If `leadership_scanner.py` fails because `yfinance` is not installed, either install it:

```powershell
pip install yfinance
```

or skip that step and build using the latest existing `leadership_scores.json`:

```powershell
python .\build_ladder.py
start .\reports\latestladder.html
```

## CSV Auto-Detection

You no longer need to rename Fidelity exports. The scripts automatically select the newest matching files in the project folder:

- Account history: `Accounts_History*.csv` or `History_for_Account*.csv`
- Positions: `Portfolio_Positions*.csv`

Examples that now work without renaming:

- `Accounts_History.csv`
- `Accounts_History (1).csv`
- `Accounts_History (2).csv`
- `Accounts_History (3).csv`
- `History_for_Account_Z25686771.csv`
- `Portfolio_Positions_Jul-09-2026.csv`

If you need to force a specific history file:

```powershell
python .\import_fidelity_csv.py --csv "Accounts_History (3).csv"
```

If you need to force a specific positions file:

```powershell
python .\import_positions.py --csv "Portfolio_Positions_Jul-09-2026.csv"
```

## Build Script

Use `build_ladder.py`. The old version-specific build name (`build_v41.py`) has been removed.

Do not run `update_portfolio.py`; that file is not part of this system.

## {VERSION} Features

- Portfolio Command Center layout
- Decision Center: Buy Today / Sell Today / Watch Closely
- Left-side portfolio hierarchy with dynamic within-category ranking
- Portfolio Classification Engine v1.0 for candidate/watch placement
- One shared ladder date drives Decision Center and footer labels
- Opportunity Score and Business Quality are separated.
- Benchmark vs QQQ card uses cash-flow-segmented TWR and keeps Personal ROI separate.
- Capital ledger records the $5,055.52 external contribution without treating it as gain.
- Adaptive learning records NVDA and AMZN manual ladder overrides for future rule proposals.
- META remains removed.
- Capital Preservation Shadow: four-pillar recession/crisis observer with daily history logging and hypothetical preservation ladders. Phase 1 never changes live orders.
- Phase 2 backlog: activate preservation-adjusted live ladders, including explicitly explained below-cost sells when capital preservation overrides the normal profit floor, after backtest and shadow validation.

## Latest Build Inputs

- Positions file: `{pos_file}`
- Account Total: {fmt_money(account_total)}
- Effective Cash: {fmt_money(effective_cash)}
- ROI Since Inception: {roi:.2f}%
- Next ladder: {LADDER_FOR}
'''
(ROOT/'README.md').write_text(readme,encoding='utf-8')
# overwrite generate_ladder.py with generator copy that is portable (adjust ROOT to cwd)
gen=Path(__file__).read_text(encoding='utf-8').replace("ROOT=Path(__file__).resolve().parent","ROOT=Path(__file__).resolve().parent")
(ROOT/'generate_ladder.py').write_text(gen,encoding='utf-8')
# validation no stale visible bad versions in html/readme
bad=[]
validation_files = [ROOT/'index.html', ROOT/'latestladder.html', ROOT/'reports'/'latestladder.html', ROOT/'README.md']
for path in validation_files:
    txt=path.read_text(encoding='utf-8')
    f=str(path.relative_to(ROOT))
    for v in ['V24','V29','V30','V31','V32','V33','V34','V35','V36','V37','V38','V39','V40']:
        if v in txt: bad.append((f,v))
if bad:
    print('STALE_VERSION_FAIL',bad); raise SystemExit(1)
print(json.dumps({'version':VERSION,'account_total':account_total,'effective_cash':effective_cash,'roi':roi,'pos_file':pos_file},indent=2))
